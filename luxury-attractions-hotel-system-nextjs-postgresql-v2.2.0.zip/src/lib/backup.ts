import { desc, eq, getTableColumns, getTableName, sql } from "drizzle-orm";
import type { PgTable } from "drizzle-orm/pg-core";
import type { PoolClient } from "pg";
import { db, pool } from "@/db";
import * as s from "@/db/schema";
import { serialisePermissions, SessionUser } from "@/lib/permissions";

export const APP_VERSION = "2.2.0";
export const BACKUP_FORMAT = "luxury-attractions-backup";

/** Contract & sales tables in foreign-key-safe order (parents first). */
const BUSINESS_TABLES: PgTable[] = [
  s.amenities, s.locations, s.hotelGroups, s.markets, s.roomCategories, s.services, s.tours,
  s.hotels, s.hotelAmenities, s.hotelContacts, s.roomTypes,
  s.hotelContactAssignments, s.occupancyRules, s.roomBedding, s.ratePeriods, s.blackoutDates,
  s.quotations, s.quotationItems, s.bookings, s.bookingItems,
  s.tripPackages, s.tripPackageItems,
];
/** Staff accounts & SMTP: merged by e-mail, never wiped. Sessions are never exported. */
const ACCOUNT_TABLES: PgTable[] = [s.users, s.smtpSettings];
const ALL_TABLES = [...BUSINESS_TABLES, ...ACCOUNT_TABLES];

export const TABLE_LABELS: Record<string, string> = {
  amenities: "Amenities", locations: "Locations", hotel_groups: "Hotel groups", markets: "Markets",
  room_categories: "Room categories", services: "Transfer services", tours: "Tours & tickets", hotels: "Hotels",
  hotel_amenities: "Hotel amenities", hotel_contacts: "Contacts", room_types: "Room types",
  hotel_contact_assignments: "Contact assignments", occupancy_rules: "Occupancy rules", room_bedding: "Room bedding",
  rate_periods: "Rate periods", blackout_dates: "Blackout dates", quotations: "Quotations", quotation_items: "Quotation stays",
  bookings: "Bookings", booking_items: "Booking segments", trip_packages: "Trip packages", trip_package_items: "Trip package lines",
  users: "Users", smtp_settings: "SMTP settings",
};

const KNOWN_TABLES = new Set(ALL_TABLES.map((table) => getTableName(table)));
const tableByName = new Map(ALL_TABLES.map((table) => [getTableName(table), table]));

/** camelCase keys used by /api/bootstrap (Laravel v2) and the dashboard data of the Next.js build. */
const TABLE_ALIASES: Record<string, string> = {
  hotelGroups: "hotel_groups", contacts: "hotel_contacts", hotelContacts: "hotel_contacts",
  contactAssignments: "hotel_contact_assignments", hotelContactAssignments: "hotel_contact_assignments",
  hotelAmenities: "hotel_amenities", roomCategories: "room_categories", rooms: "room_types", roomTypes: "room_types",
  bedding: "room_bedding", roomBedding: "room_bedding", occupancies: "occupancy_rules", occupancyRules: "occupancy_rules",
  rates: "rate_periods", ratePeriods: "rate_periods", blackouts: "blackout_dates", blackoutDates: "blackout_dates",
  bookingItems: "booking_items", quotationItems: "quotation_items", tripPackages: "trip_packages",
  tripPackageItems: "trip_package_items", smtp: "smtp_settings", smtpSettings: "smtp_settings",
};

type ColMeta = { key: string; name: string; type: string; notNull: boolean; hasDefault: boolean };

function columnsOf(table: PgTable): ColMeta[] {
  return Object.entries(getTableColumns(table)).map(([key, col]) => ({
    key,
    name: col.name,
    type: col.columnType,
    notNull: col.notNull,
    hasDefault: col.hasDefault,
  }));
}

type Queryable = Pick<PoolClient, "query">;
type Row = Record<string, unknown>;

/* ---------------------------------------------------------------- export --- */

async function readTable(client: Queryable, table: PgTable): Promise<Row[]> {
  const cols = columnsOf(table);
  const list = cols
    .map((c) => (c.type.startsWith("PgDate") ? `to_char("${c.name}", 'YYYY-MM-DD') AS "${c.name}"` : `"${c.name}"`))
    .join(", ");
  const result = await client.query(`SELECT ${list} FROM "${getTableName(table)}" ORDER BY "id"`);
  return result.rows.map((row: Row) => {
    for (const c of cols) if (row[c.name] instanceof Date) row[c.name] = (row[c.name] as Date).toISOString();
    return row;
  });
}

export type BackupFile = { _meta: { format: string; version: number; appVersion: string; createdAt: string; counts: Record<string, number>; note: string } } & Record<string, unknown>;

/**
 * Whole database as JSON. Tables sit at the top level with snake_case columns — the same
 * layout as the Laravel build's database/demo.json, so the file works in both systems.
 */
export async function exportAll(note = ""): Promise<BackupFile> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY");
    const tables: Record<string, Row[]> = {};
    for (const table of ALL_TABLES) tables[getTableName(table)] = await readTable(client, table);
    await client.query("COMMIT");
    const counts = Object.fromEntries(Object.entries(tables).map(([name, rows]) => [name, rows.length]));
    return { _meta: { format: BACKUP_FORMAT, version: 1, appVersion: APP_VERSION, createdAt: new Date().toISOString(), counts, note }, ...tables };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

export async function getTableCounts(client: Queryable = pool): Promise<Record<string, number>> {
  const parts = ALL_TABLES.map((table) => `SELECT '${getTableName(table)}' AS t, count(*)::int AS c FROM "${getTableName(table)}"`);
  const result = await client.query(parts.join(" UNION ALL "));
  return Object.fromEntries(result.rows.map((row: { t: string; c: number }) => [row.t, row.c]));
}

/** Rows in the contract & sales tables (excludes users/SMTP). */
export async function businessRowCount(): Promise<number> {
  const counts = await getTableCounts();
  return BUSINESS_TABLES.reduce((sum, table) => sum + (counts[getTableName(table)] ?? 0), 0);
}

/* ------------------------------------------------------------ parse files --- */

export type ParsedBackup = { source: string; tables: Record<string, Row[]>; ignored: string[]; warnings: string[] };

export function parseBackupFile(text: string): ParsedBackup {
  const trimmed = text.replace(/^\uFEFF/, "").trim();
  if (!trimmed) throw new Error("The file is empty.");
  if (trimmed.startsWith("{")) {
    let raw: unknown;
    try {
      raw = JSON.parse(trimmed);
    } catch {
      throw new Error("This JSON file could not be read — it may be incomplete.");
    }
    return parseJsonBackup(raw);
  }
  return parseSqlDump(trimmed);
}

function parseJsonBackup(raw: unknown): ParsedBackup {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new Error("Unrecognised JSON file.");
  let obj = raw as Row;
  let source = "JSON data file (Laravel demo.json layout)";
  const meta = obj._meta as { format?: string } | undefined;
  if (meta?.format === BACKUP_FORMAT) source = "Luxury Attractions backup file";
  if (obj.data && typeof obj.data === "object" && !Array.isArray(obj.data)) {
    // Response of GET /api/bootstrap on the Laravel v2 system: { data: {...}, users: [...], smtp: {...} }
    source = "Live system export (/api/bootstrap)";
    const extra: Row = {};
    if (Array.isArray(obj.users)) extra.users = obj.users;
    if (obj.smtp && typeof obj.smtp === "object") extra.smtp = obj.smtp;
    obj = { ...(obj.data as Row), ...extra };
  }
  if (obj.tables && typeof obj.tables === "object" && !Array.isArray(obj.tables)) obj = obj.tables as Row;

  const tables: Record<string, Row[]> = {};
  const ignored: string[] = [];
  for (const [key, value] of Object.entries(obj)) {
    if (key.startsWith("_")) continue;
    const name = TABLE_ALIASES[key] ?? (KNOWN_TABLES.has(key) ? key : null);
    if (!name) {
      if (Array.isArray(value)) ignored.push(key);
      continue;
    }
    const rows = Array.isArray(value) ? value : value && typeof value === "object" ? [value] : null;
    if (!rows) continue;
    tables[name] = rows.filter((row): row is Row => Boolean(row) && typeof row === "object" && !Array.isArray(row));
  }
  if (Object.keys(tables).length === 0) throw new Error("No hotel-system tables were found in this file.");
  return { source, tables, ignored, warnings: [] };
}

/* phpMyAdmin / mysqldump .sql parser (INSERT statements, with or without column lists). */

const isWs = (code: number) => code === 32 || code === 9 || code === 10 || code === 13;
const ESCAPES: Record<string, string> = { "0": "\0", "'": "'", '"': '"', b: "\b", n: "\n", r: "\r", t: "\t", Z: "\x1a", "\\": "\\", "%": "\\%", _: "\\_" };

function readQuoted(text: string, start: number): [string, number] {
  const quote = text[start];
  let i = start + 1;
  let chunk = i;
  let out = "";
  while (i < text.length) {
    const ch = text[i];
    if (ch === "\\") {
      out += text.slice(chunk, i) + (ESCAPES[text[i + 1]] ?? text[i + 1] ?? "");
      i += 2;
      chunk = i;
      continue;
    }
    if (ch === quote) {
      if (text[i + 1] === quote) {
        out += text.slice(chunk, i) + quote;
        i += 2;
        chunk = i;
        continue;
      }
      return [out + text.slice(chunk, i), i + 1];
    }
    i++;
  }
  return [out + text.slice(chunk), text.length];
}

function findStatementEnd(text: string, start: number): number {
  let quote = "";
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (quote) {
      if (ch === "\\" && quote !== "`") { i++; continue; }
      if (ch === quote) {
        if (text[i + 1] === quote) { i++; continue; }
        quote = "";
      }
      continue;
    }
    if (ch === "'" || ch === '"' || ch === "`") { quote = ch; continue; }
    if (ch === ";") return i;
  }
  return text.length;
}

function parseTuples(text: string, start: number): unknown[][] {
  const rows: unknown[][] = [];
  const n = text.length;
  let i = start;
  while (i < n) {
    while (i < n && (text[i] === "," || isWs(text.charCodeAt(i)))) i++;
    if (i >= n || text[i] !== "(") break;
    i++;
    const row: unknown[] = [];
    while (i < n) {
      while (i < n && isWs(text.charCodeAt(i))) i++;
      if (text[i] === "_") {
        const introducer = /^_\w+\s*(?=')/.exec(text.slice(i, i + 24));
        if (introducer) i += introducer[0].length;
      }
      if (text[i] === "'" || text[i] === '"') {
        const [value, next] = readQuoted(text, i);
        row.push(value);
        i = next;
      } else if (text[i] === ")") {
        i++;
        break;
      } else {
        let j = i;
        while (j < n && text[j] !== "," && text[j] !== ")") j++;
        const token = text.slice(i, j).trim();
        row.push(/^null$/i.test(token) ? null : token);
        i = j;
      }
      while (i < n && isWs(text.charCodeAt(i))) i++;
      if (text[i] === ",") { i++; continue; }
      if (text[i] === ")") { i++; break; }
    }
    if (row.length) rows.push(row);
  }
  return rows;
}

const identifier = "(?:[`\"]?\\w+[`\"]?\\.)?[`\"]?(\\w+)[`\"]?";
const CREATE_RE = new RegExp(`^CREATE\\s+TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?${identifier}\\s*\\(`, "i");
const INSERT_RE = new RegExp(`^(?:INSERT|REPLACE)\\s+(?:LOW_PRIORITY\\s+|DELAYED\\s+|HIGH_PRIORITY\\s+)?(?:IGNORE\\s+)?INTO\\s+${identifier}\\s*(\\(([^)]*)\\))?\\s*VALUES\\s*`, "i");

export function parseSqlDump(text: string): ParsedBackup {
  const tables: Record<string, Row[]> = {};
  const createColumns: Record<string, string[]> = {};
  const ignored = new Set<string>();
  const warnings: string[] = [];
  const n = text.length;
  let i = 0;
  let statements = 0;

  while (i < n) {
    const code = text.charCodeAt(i);
    if (isWs(code) || text[i] === ";") { i++; continue; }
    if ((text[i] === "-" && text[i + 1] === "-") || text[i] === "#") {
      const end = text.indexOf("\n", i);
      i = end < 0 ? n : end + 1;
      continue;
    }
    if (text[i] === "/" && text[i + 1] === "*") {
      const end = text.indexOf("*/", i + 2);
      i = end < 0 ? n : end + 2;
      continue;
    }
    const end = findStatementEnd(text, i);
    const stmt = text.slice(i, end);
    i = end + 1;
    statements++;

    const create = CREATE_RE.exec(stmt);
    if (create) {
      const body = stmt.slice(create[0].length);
      createColumns[create[1]] = body
        .split("\n")
        .map((line) => /^\s*[`"](\w+)[`"]\s+\w/.exec(line)?.[1])
        .filter((name): name is string => Boolean(name));
      continue;
    }
    const insert = INSERT_RE.exec(stmt);
    if (!insert) continue;
    const name = insert[1];
    if (!KNOWN_TABLES.has(name)) {
      ignored.add(name);
      continue;
    }
    const columns = insert[3]
      ? insert[3].split(",").map((col) => col.trim().replace(/^[`"]|[`"]$/g, ""))
      : createColumns[name] ?? columnsOf(tableByName.get(name)!).map((col) => col.name);
    const target = (tables[name] ??= []);
    for (const values of parseTuples(stmt, insert[0].length)) {
      if (values.length !== columns.length) {
        warnings.push(`${name}: a row with ${values.length} values did not match ${columns.length} columns and was skipped.`);
        continue;
      }
      const row: Row = {};
      columns.forEach((col, index) => { row[col] = values[index]; });
      target.push(row);
    }
  }
  if (statements === 0 || Object.keys(tables).length === 0) {
    throw new Error("No INSERT statements for hotel-system tables were found. Export the database from phpMyAdmin as SQL (structure + data).");
  }
  return { source: "MySQL / phpMyAdmin SQL export", tables, ignored: Array.from(ignored), warnings: warnings.slice(0, 20) };
}

/* --------------------------------------------------------- value coercion --- */

const DEFAULT = Symbol("default");
class SkipRow extends Error {}

function coerce(col: ColMeta, raw: unknown): unknown {
  if (raw === undefined || raw === null) return null;
  if (raw === "" && col.type !== "PgText") return null;
  switch (col.type) {
    case "PgSerial":
    case "PgInteger":
    case "PgSmallInt":
    case "PgBigInt53": {
      const num = typeof raw === "boolean" ? (raw ? 1 : 0) : Number(raw);
      return Number.isFinite(num) ? Math.trunc(num) : null;
    }
    case "PgNumeric": {
      const num = Number(raw);
      return Number.isFinite(num) ? String(num) : null;
    }
    case "PgBoolean":
      if (typeof raw === "boolean") return raw;
      if (typeof raw === "number") return raw !== 0;
      return ["1", "t", "true", "yes", "y", "on"].includes(String(raw).trim().toLowerCase());
    case "PgDateString":
    case "PgDate": {
      const match = /^(\d{4}-\d{2}-\d{2})/.exec(raw instanceof Date ? raw.toISOString() : String(raw));
      return match && match[1] !== "0000-00-00" ? match[1] : null;
    }
    case "PgTimestamp":
    case "PgTimestampString": {
      if (raw instanceof Date) return raw.toISOString();
      const value = String(raw).trim();
      if (value.startsWith("0000-00-00")) return null;
      // MySQL DATETIME/TIMESTAMP values from the Laravel build are stored in UTC.
      if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2}(\.\d+)?)?$/.test(value)) return `${value.replace(" ", "T")}Z`;
      if (/^\d{9,13}$/.test(value)) return new Date(Number(value) * (value.length <= 10 ? 1000 : 1)).toISOString();
      const date = new Date(value);
      return Number.isNaN(date.getTime()) ? null : date.toISOString();
    }
    default:
      if (Array.isArray(raw)) return raw.map(String).join(",");
      if (typeof raw === "object") return JSON.stringify(raw);
      return String(raw);
  }
}

function prepareRow(cols: ColMeta[], row: Row): unknown[] {
  return cols.map((col) => {
    const raw = col.name in row ? row[col.name] : row[col.key];
    const value = coerce(col, raw);
    if (value !== null) return value;
    if (!col.notNull) return null;
    if (col.hasDefault) return DEFAULT;
    if (col.type === "PgText") return "";
    if (col.type === "PgInteger" || col.type === "PgSmallInt" || col.type === "PgBigInt53") return 0;
    if (col.type === "PgNumeric") return "0";
    if (col.type === "PgBoolean") return false;
    throw new SkipRow(col.name);
  });
}

async function insertRows(client: Queryable, table: string, cols: ColMeta[], rows: unknown[][], ignoreConflicts: boolean): Promise<number> {
  if (rows.length === 0) return 0;
  const columnList = cols.map((col) => `"${col.name}"`).join(", ");
  const chunkSize = Math.max(1, Math.floor(20000 / cols.length));
  let inserted = 0;
  for (let start = 0; start < rows.length; start += chunkSize) {
    const params: unknown[] = [];
    const tuples = rows.slice(start, start + chunkSize).map((row) => {
      const cells = row.map((value) => {
        if (value === DEFAULT) return "DEFAULT";
        params.push(value);
        return `$${params.length}`;
      });
      return `(${cells.join(", ")})`;
    });
    const result = await client.query(
      `INSERT INTO "${table}" (${columnList}) VALUES ${tuples.join(", ")}${ignoreConflicts ? " ON CONFLICT DO NOTHING" : ""}`,
      params,
    );
    inserted += result.rowCount ?? 0;
  }
  return inserted;
}

async function resetSequence(client: Queryable, table: string) {
  await client.query(
    `SELECT setval(pg_get_serial_sequence('"${table}"', 'id'), GREATEST(COALESCE(MAX("id"), 0), 1), MAX("id") IS NOT NULL) FROM "${table}"`,
  );
}

/* ----------------------------------------------------------------- import --- */

export type ImportMode = "replace" | "merge";
export type TableReport = { table: string; label: string; current: number; incoming: number; inserted: number; skipped: number; inFile: boolean };
export type ImportReport = {
  dryRun: boolean;
  mode: ImportMode;
  source: string;
  tables: TableReport[];
  users: { incoming: number; created: number; updated: number; unchanged: number };
  smtp: "none" | "kept" | "imported";
  warnings: string[];
  ignored: string[];
  snapshotId: number | null;
};

/**
 * Applies a parsed file. "replace" makes contracts & sales data identical to the file; "merge"
 * only adds records whose id is not used yet and never changes existing rows. Staff accounts are
 * matched by e-mail and are never deleted; the signed-in account is never modified.
 * Everything runs in one transaction (all-or-nothing) after an automatic restore point.
 */
export async function runImport(
  parsed: ParsedBackup,
  options: { mode: ImportMode; dryRun: boolean; actor: SessionUser | null; snapshotNote?: string },
): Promise<ImportReport> {
  const { mode, dryRun, actor } = options;
  const warnings = [...parsed.warnings];
  const current = await getTableCounts();

  const prepared = BUSINESS_TABLES.map((table) => {
    const name = getTableName(table);
    const cols = columnsOf(table);
    const incoming = parsed.tables[name];
    const rows: unknown[][] = [];
    let skipped = 0;
    for (const row of incoming ?? []) {
      try {
        rows.push(prepareRow(cols, row));
      } catch (error) {
        if (!(error instanceof SkipRow)) throw error;
        skipped++;
      }
    }
    if (skipped) warnings.push(`${TABLE_LABELS[name]}: ${skipped} row(s) skipped because a required value (e.g. a date) was missing.`);
    return { name, cols, rows, skipped, inFile: incoming !== undefined };
  });

  if (mode === "replace") {
    const emptied = prepared.filter((item) => !item.inFile && (current[item.name] ?? 0) > 0).map((item) => TABLE_LABELS[item.name]);
    if (emptied.length) warnings.push(`Not in the file and will be emptied: ${emptied.join(", ")}.`);
  }

  const incomingUsers = (parsed.tables.users ?? []).filter((row) => String(row.email ?? "").trim());
  const incomingSmtp = parsed.tables.smtp_settings?.[0];

  const report: ImportReport = {
    dryRun,
    mode,
    source: parsed.source,
    tables: prepared.map((item) => ({
      table: item.name,
      label: TABLE_LABELS[item.name],
      current: current[item.name] ?? 0,
      incoming: item.rows.length,
      inserted: 0,
      skipped: item.skipped,
      inFile: item.inFile,
    })),
    users: { incoming: incomingUsers.length, created: 0, updated: 0, unchanged: 0 },
    smtp: incomingSmtp ? "imported" : "none",
    warnings,
    ignored: parsed.ignored,
    snapshotId: null,
  };
  if (dryRun) return report;

  report.snapshotId = await createSnapshot("pre-import", options.snapshotNote ?? `Automatic restore point before ${mode} import (${parsed.source})`, actor?.email ?? "system");

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(551177)");
    if (mode === "replace") {
      await client.query(`TRUNCATE ${BUSINESS_TABLES.map((table) => `"${getTableName(table)}"`).join(", ")} RESTART IDENTITY CASCADE`);
    }
    for (const [index, item] of prepared.entries()) {
      report.tables[index].inserted = await insertRows(client, item.name, item.cols, item.rows, mode === "merge");
      await resetSequence(client, item.name);
    }

    // Users: matched by e-mail. Never deleted; the signed-in account is left untouched.
    const userCols = columnsOf(s.users).filter((col) => col.name !== "id");
    for (const raw of incomingUsers) {
      const row: Row = { ...raw, email: String(raw.email).trim().toLowerCase() };
      row.permissions = serialisePermissions(raw.permissions ?? "");
      const hash = String(raw.password_hash ?? raw.passwordHash ?? "");
      const existing = await client.query(`SELECT id FROM "users" WHERE lower(email) = $1 LIMIT 1`, [row.email]);
      if (existing.rowCount) {
        const sameAsActor = actor && actor.email.toLowerCase() === row.email;
        if (mode === "merge" || sameAsActor) { report.users.unchanged++; continue; }
        const role = String(raw.role ?? "") || "agent";
        await client.query(
          `UPDATE "users" SET name = COALESCE(NULLIF($2, ''), name), role = $3, permissions = $4, phone = $5, active = $6${hash ? ", password_hash = $7" : ""} WHERE id = $1`,
          [existing.rows[0].id, String(raw.name ?? ""), role, row.permissions, String(raw.phone ?? ""), coerce({ key: "active", name: "active", type: "PgBoolean", notNull: true, hasDefault: true }, raw.active ?? true), ...(hash ? [hash] : [])],
        );
        report.users.updated++;
      } else {
        if (!hash) row.must_change_password = true;
        try {
          await insertRows(client, "users", userCols, [prepareRow(userCols, row)], true);
          report.users.created++;
        } catch (error) {
          if (!(error instanceof SkipRow)) throw error;
        }
      }
    }
    await resetSequence(client, "users");

    // SMTP: one row. A masked/empty password keeps the password already stored here.
    if (incomingSmtp) {
      const existing = await client.query(`SELECT id, password FROM "smtp_settings" ORDER BY id LIMIT 1`);
      if (mode === "merge" && existing.rowCount) {
        report.smtp = "kept";
      } else {
        const password = String(incomingSmtp.password ?? "");
        const row: Row = { ...incomingSmtp, password: !password || /^\*+$/.test(password) ? existing.rows[0]?.password ?? "" : password };
        const cols = columnsOf(s.smtpSettings).filter((col) => col.name !== "id");
        await client.query(`DELETE FROM "smtp_settings"`);
        await insertRows(client, "smtp_settings", cols, [prepareRow(cols, row)], false);
      }
    }

    await client.query(
      `INSERT INTO "app_settings" (key, value) VALUES ('initialized_at', $1), ('last_import', $2)
       ON CONFLICT (key) DO UPDATE SET value = CASE WHEN app_settings.key = 'initialized_at' THEN app_settings.value ELSE EXCLUDED.value END, updated_at = now()`,
      [new Date().toISOString(), JSON.stringify({ at: new Date().toISOString(), mode, source: parsed.source, by: actor?.email ?? "setup" })],
    );
    await client.query("COMMIT");
    return report;
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Import failed and nothing was changed (${message}).${mode === "merge" ? " If records depend on rows that already exist with other ids, use Replace instead." : ""}`);
  } finally {
    client.release();
  }
}

/* -------------------------------------------------------------- snapshots --- */

export type SnapshotInfo = { id: number; kind: string; note: string; createdBy: string; rowCount: number; sizeBytes: number; tableCounts: Record<string, number>; createdAt: string };

export async function createSnapshot(kind: string, note: string, createdBy: string): Promise<number> {
  const backup = await exportAll(note);
  const payload = JSON.stringify(backup);
  const counts = backup._meta.counts;
  const rowCount = Object.values(counts).reduce((sum, value) => sum + value, 0);
  const [row] = await db
    .insert(s.backupSnapshots)
    .values({ kind, note, createdBy, rowCount, sizeBytes: Buffer.byteLength(payload), tableCounts: JSON.stringify(counts), payload })
    .returning({ id: s.backupSnapshots.id });
  // Keep the newest 14 daily snapshots and the newest 40 of the other kinds.
  await db.execute(sql`DELETE FROM backup_snapshots WHERE id IN (SELECT id FROM backup_snapshots WHERE kind = 'auto' ORDER BY created_at DESC OFFSET 14)`);
  await db.execute(sql`DELETE FROM backup_snapshots WHERE id IN (SELECT id FROM backup_snapshots WHERE kind <> 'auto' ORDER BY created_at DESC OFFSET 40)`);
  return row.id;
}

export async function listSnapshots(): Promise<SnapshotInfo[]> {
  const rows = await db
    .select({
      id: s.backupSnapshots.id, kind: s.backupSnapshots.kind, note: s.backupSnapshots.note, createdBy: s.backupSnapshots.createdBy,
      rowCount: s.backupSnapshots.rowCount, sizeBytes: s.backupSnapshots.sizeBytes, tableCounts: s.backupSnapshots.tableCounts, createdAt: s.backupSnapshots.createdAt,
    })
    .from(s.backupSnapshots)
    .orderBy(desc(s.backupSnapshots.createdAt), desc(s.backupSnapshots.id))
    .limit(60);
  return rows.map((row) => {
    let tableCounts: Record<string, number> = {};
    try { tableCounts = JSON.parse(row.tableCounts); } catch { /* keep empty */ }
    return { ...row, tableCounts, createdAt: row.createdAt.toISOString() };
  });
}

export async function getSnapshotPayload(id: number): Promise<{ payload: string; createdAt: Date; kind: string } | null> {
  const [row] = await db
    .select({ payload: s.backupSnapshots.payload, createdAt: s.backupSnapshots.createdAt, kind: s.backupSnapshots.kind })
    .from(s.backupSnapshots)
    .where(eq(s.backupSnapshots.id, id))
    .limit(1);
  return row ?? null;
}

export async function deleteSnapshot(id: number) {
  await db.delete(s.backupSnapshots).where(eq(s.backupSnapshots.id, id));
}

/** One automatic snapshot per 24 hours (called after the dashboard renders). */
export async function autoSnapshotIfDue(createdBy: string) {
  try {
    const claimed = await db.execute(sql`
      INSERT INTO app_settings (key, value) VALUES ('last_auto_snapshot_at', ${new Date().toISOString()})
      ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()
      WHERE app_settings.updated_at < now() - interval '24 hours'
      RETURNING key`);
    if (!claimed.rows.length) return;
    if ((await businessRowCount()) === 0) return;
    await createSnapshot("auto", "Daily automatic snapshot", createdBy);
  } catch (error) {
    console.error("Automatic snapshot failed", error);
  }
}

/* --------------------------------------------------------------- settings --- */

export async function getSetting(key: string): Promise<string | null> {
  const [row] = await db.select({ value: s.appSettings.value }).from(s.appSettings).where(eq(s.appSettings.key, key)).limit(1);
  return row?.value ?? null;
}

export async function setSetting(key: string, value: string) {
  await db
    .insert(s.appSettings)
    .values({ key, value })
    .onConflictDoUpdate({ target: s.appSettings.key, set: { value, updatedAt: new Date() } });
}
