import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import bcrypt from "bcryptjs";
import { cookies, headers } from "next/headers";
import { NextResponse } from "next/server";
import { cache } from "react";
import { and, eq, gt, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { can, parsePermissions, Permission, SessionUser } from "@/lib/permissions";

export const SESSION_COOKIE = "la_session";
const SESSION_DAYS = 14; // same as SESSION_LIFETIME=20160 minutes in the Laravel build

/* -------------------------------- passwords -------------------------------- */

/** New hashes use the original Next.js format: scrypt:<salt>:<hex>. */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt:${salt}:${hash}`;
}

/** Accepts scrypt (Next.js) and bcrypt $2y$/$2a$/$2b$ (Laravel/PHP) so imported users keep their passwords. */
export function verifyPassword(password: string, stored: string | null | undefined): boolean {
  const value = String(stored ?? "");
  if (!value || !password) return false;
  try {
    if (value.startsWith("scrypt:")) {
      const [, salt, hash] = value.split(":");
      if (!salt || !hash) return false;
      const expected = Buffer.from(hash, "hex");
      const derived = scryptSync(password, salt, expected.length || 64);
      return expected.length === derived.length && timingSafeEqual(expected, derived);
    }
    if (/^\$2[abxy]\$/.test(value)) {
      return bcrypt.compareSync(password, value.replace(/^\$2[xy]\$/, "$2b$"));
    }
  } catch {
    return false;
  }
  return false;
}

/* --------------------------------- sessions -------------------------------- */

const tokenHash = (token: string) => createHash("sha256").update(token).digest("hex");

async function isHttps() {
  const h = await headers();
  return h.get("x-forwarded-proto") === "https" || process.env.COOKIE_SECURE === "true";
}

/** Creates a session row and sets the cookie (route handlers only). */
export async function startSession(userId: number) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400_000);
  await db.insert(sessions).values({ token: tokenHash(token), userId, expiresAt });
  // Opportunistic clean-up of expired sessions.
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", secure: await isHttps(), path: "/", expires: expiresAt });
}

export async function endSession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.token, tokenHash(token)));
  jar.delete(SESSION_COOKIE);
}

/** The signed-in user for this request (memoised per request). */
export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    const [row] = await db
      .select({ user: users })
      .from(sessions)
      .innerJoin(users, eq(users.id, sessions.userId))
      .where(and(eq(sessions.token, tokenHash(token)), gt(sessions.expiresAt, new Date())))
      .limit(1);
    if (!row || !row.user.active) return null;
    return {
      id: row.user.id,
      name: row.user.name,
      email: row.user.email,
      role: row.user.role,
      permissions: parsePermissions(row.user.permissions),
      mustChangePassword: row.user.mustChangePassword,
    };
  } catch {
    return null;
  }
});

export async function hasAnyUser(): Promise<boolean> {
  try {
    const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
    return (row?.count ?? 0) > 0;
  } catch {
    return false;
  }
}

/**
 * Route guard. Returns a JSON error response when the caller is not signed in (401)
 * or lacks the permission (403); returns null when the request may continue.
 * Pass no permission to only require a signed-in user.
 */
export async function requirePermission(permission?: Permission): Promise<NextResponse | null> {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Please sign in to continue." }, { status: 401 });
  if (permission && !can(user, permission)) return NextResponse.json({ error: "You do not have permission to do that." }, { status: 403 });
  return null;
}
