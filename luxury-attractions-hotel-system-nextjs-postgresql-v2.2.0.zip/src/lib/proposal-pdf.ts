import { jsPDF } from "jspdf";

// Client-facing PDF used as the e-mail attachment. Like the print views, it shows the quoted
// selling price only — net hotel cost and markup are never included.

export type ProposalStay = { hotel: string; room: string; board: string; checkIn: string; checkOut: string; nights: number; adults: number; children: number; rooms: number };
export type ProposalLine = { date: string | null; time: string; name: string; pickup: string; dropoff: string; persons: number; vehicles: number; priceType: string };
export type ProposalDoc = {
  kind: "quotation" | "trip";
  reference: string;
  title: string;
  createdAt: string;
  clientName: string;
  clientCompany: string;
  clientEmail: string;
  clientPhone: string;
  validUntil: string | null;
  startDate: string | null;
  endDate: string | null;
  stays: ProposalStay[];
  lines: ProposalLine[];
  total: number;
  currency: string;
  includeTax: boolean;
  tax: number;
  notes: string;
};

const TEAL: [number, number, number] = [23, 78, 72];
const BRONZE: [number, number, number] = [166, 110, 66];

/** Standard PDF fonts only cover Latin-1; map common symbols and drop the rest. */
const clean = (value: string) =>
  String(value ?? "")
    .replace(/→/g, "->")
    .replace(/[–—]/g, "-")
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/…/g, "...")
    .replace(/[^\x00-\xff]/g, "");

export const formatDay = (date: string | null) =>
  date ? new Intl.DateTimeFormat("en-GB", { weekday: "short", day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" }).format(new Date(`${date.slice(0, 10)}T00:00:00Z`)) : "TBC";

export const money = (value: number, currency = "AED") =>
  `${currency} ${Number(value || 0).toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export function proposalFileName(reference: string, title: string) {
  const slug = `${reference}-${title}`.replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").slice(0, 80);
  return `${slug || "proposal"}.pdf`;
}

export function buildProposalPdf(p: ProposalDoc): string {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const width = doc.internal.pageSize.getWidth();
  const height = doc.internal.pageSize.getHeight();
  const left = 15;
  const right = width - 15;
  let y = 0;

  const ensure = (space: number) => {
    if (y + space > height - 18) {
      doc.addPage();
      y = 18;
    }
  };
  const text = (value: string, x: number, size = 10, style: "normal" | "bold" = "normal", color: [number, number, number] = [30, 41, 59]) => {
    doc.setFont("helvetica", style);
    doc.setFontSize(size);
    doc.setTextColor(...color);
    doc.text(clean(value), x, y);
  };
  const wrapped = (value: string, x: number, maxWidth: number, size = 10, style: "normal" | "bold" = "normal") => {
    doc.setFont("helvetica", style);
    doc.setFontSize(size);
    doc.setTextColor(30, 41, 59);
    const lines = doc.splitTextToSize(clean(value), maxWidth) as string[];
    for (const line of lines) {
      ensure(5);
      doc.text(line, x, y);
      y += size * 0.45;
    }
  };
  const heading = (label: string) => {
    ensure(14);
    y += 4;
    doc.setFillColor(...TEAL);
    doc.rect(left, y - 4, 1.4, 5.5, "F");
    text(label.toUpperCase(), left + 4, 11, "bold", TEAL);
    y += 6;
  };

  // Header band
  doc.setFillColor(...TEAL);
  doc.rect(0, 0, width, 30, "F");
  y = 14;
  text("LUXURY ATTRACTIONS", left, 17, "bold", [255, 255, 255]);
  y = 21;
  text(p.kind === "trip" ? "Trip Package Itinerary" : "Hotel Stay Proposal", left, 10, "normal", [204, 238, 232]);
  y = 14;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text(clean(p.reference), right, y, { align: "right" });
  y = 21;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(formatDay(p.createdAt), right, y, { align: "right" });

  y = 40;
  wrapped(p.title || (p.kind === "trip" ? "Trip package" : "Hotel proposal"), left, right - left, 14, "bold");
  y += 2;

  const info: [string, string][] = [
    ["Client", p.clientName],
    ["Company / Partner", p.clientCompany],
    ["Email", p.clientEmail],
    ["Phone / WhatsApp", p.clientPhone],
    p.kind === "trip" ? ["Travel dates", `${formatDay(p.startDate)} - ${formatDay(p.endDate)}`] : ["Valid until", p.validUntil ? formatDay(p.validUntil) : "-"],
  ];
  for (const [label, value] of info.filter(([, value]) => value)) {
    ensure(6);
    text(label, left, 9, "normal", [100, 116, 139]);
    text(value, left + 42, 10, "bold");
    y += 5.5;
  }

  if (p.stays.length) {
    heading(p.kind === "trip" ? "Part 1 - Hotel stays" : "Hotel stays");
    p.stays.forEach((stay, index) => {
      ensure(16);
      text(`${index + 1}. ${stay.hotel}`, left, 10.5, "bold");
      y += 5;
      wrapped(`${stay.room} · ${stay.board}`, left + 4, right - left - 4, 9.5);
      const guests = `${stay.adults} adult${stay.adults === 1 ? "" : "s"}${stay.children ? `, ${stay.children} child${stay.children === 1 ? "" : "ren"}` : ""}`;
      wrapped(`${formatDay(stay.checkIn)} -> ${formatDay(stay.checkOut)}  ·  ${stay.nights} night${stay.nights === 1 ? "" : "s"}  ·  ${stay.rooms} room${stay.rooms === 1 ? "" : "s"}  ·  ${guests}`, left + 4, right - left - 4, 9.5);
      y += 2;
    });
  }

  if (p.lines.length) {
    heading(p.kind === "trip" && p.stays.length ? "Part 2 - Tours, tickets & transfers" : "Tours, tickets & transfers");
    for (const line of p.lines) {
      ensure(14);
      text(`${formatDay(line.date)}${line.time ? `  ${line.time}` : ""}`, left, 9, "bold", BRONZE);
      y += 4.5;
      wrapped(line.name, left + 4, right - left - 4, 10, "bold");
      const route = [line.pickup && `Pick-up: ${line.pickup}`, line.dropoff && `Drop-off: ${line.dropoff}`].filter(Boolean).join("  ·  ");
      const qty = line.vehicles > 0 && /vehicle|private/i.test(line.priceType) ? `${line.vehicles} vehicle(s)` : `${line.persons} person(s)`;
      wrapped([route, qty].filter(Boolean).join("  ·  "), left + 4, right - left - 4, 9);
      y += 2;
    }
  }

  // Price box
  ensure(28);
  y += 4;
  doc.setFillColor(234, 244, 242);
  doc.roundedRect(left, y, right - left, p.includeTax || !p.tax ? 16 : 22, 2, 2, "F");
  y += 7;
  text("Total price", left + 5, 10, "bold", TEAL);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.setTextColor(...TEAL);
  doc.text(clean(money(p.total, p.currency)), right - 5, y, { align: "right" });
  y += 5.5;
  text(p.includeTax ? "Tourism tax included." : p.tax ? `Tourism tax payable at the hotel: ${money(p.tax, p.currency)}` : "", left + 5, 8.5, "normal", [71, 85, 105]);
  y += p.includeTax || !p.tax ? 8 : 14;

  if (p.notes) {
    heading("Notes");
    wrapped(p.notes, left, right - left, 9.5);
  }

  ensure(14);
  y += 6;
  wrapped("Rates are subject to availability at the time of confirmation. We look forward to welcoming your guests.", left, right - left, 8.5);

  const pages = doc.getNumberOfPages();
  for (let page = 1; page <= pages; page++) {
    doc.setPage(page);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text("Luxury Attractions · hotels.luxuryattractions.com", left, height - 8);
    doc.text(`Page ${page} of ${pages}`, right, height - 8, { align: "right" });
  }
  return doc.output("datauristring").split(",").pop() ?? "";
}
