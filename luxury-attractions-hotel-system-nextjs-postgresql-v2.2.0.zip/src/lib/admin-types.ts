import type { ImportReport, SnapshotInfo } from "@/lib/backup";

export type AdminUser = {
  id: number;
  name: string;
  email: string;
  role: string;
  permissions: string[];
  phone: string;
  active: boolean;
  mustChangePassword: boolean;
  lastLoginAt: string | null;
};

export type SmtpView = {
  host: string;
  port: number;
  secure: boolean;
  username: string;
  password: string; // "********" when a password is stored
  fromName: string;
  fromEmail: string;
  replyTo: string;
  bccSelf: boolean;
  active: boolean;
} | null;

export type AdminData = {
  users: AdminUser[];
  smtp: SmtpView;
  snapshots: SnapshotInfo[];
  counts: Record<string, number>;
  lastImport: string | null;
  lastAutoSnapshot: string | null;
  version: string;
};

export type { ImportReport, SnapshotInfo };
