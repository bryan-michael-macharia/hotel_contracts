// Direct links to every screen of the dashboard (e.g. /?view=quotations). Used by the server
// (sign-in redirects keep the requested screen) and the browser (the address bar follows the screen).

export const SCREEN_LINKS = [
  { view: "search", label: "Search & compare" },
  { view: "quotations", label: "Quotations" },
  { view: "trips", label: "Trip Packages" },
  { view: "dashboard", label: "Overview" },
  { view: "bookings", label: "Bookings" },
  { view: "hotels", label: "Hotels" },
  { view: "rooms", label: "Room types" },
  { view: "rates", label: "Rates & board" },
  { view: "blackouts", label: "Blackout dates" },
  { view: "admin", label: "Users & settings" },
] as const;

/** Tabs of the Users & settings screen: /?view=admin&tab=backups */
export const ADMIN_TABS = ["users", "backups", "email"] as const;

/** Friendly names that also work in links, e.g. /?view=overview */
export const VIEW_ALIASES: Record<string, string> = { overview: "dashboard", settings: "admin", users: "admin", backups: "admin" };

/** URL of a screen. The Search screen is the home page. */
export function screenHref(view: string, tab?: string): string {
  if (view === "search" && !tab) return "/";
  const params = new URLSearchParams({ view });
  if (tab) params.set("tab", tab);
  return `/?${params.toString()}`;
}

/** Only same-site paths are accepted as the page to open after sign-in (prevents open redirects). */
export function safeNextPath(value: unknown): string {
  if (typeof value !== "string" || !value.startsWith("/") || value.startsWith("//") || value.startsWith("/\\")) return "/";
  return value;
}
