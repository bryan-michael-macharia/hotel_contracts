// Permission catalogue shared by the server (route guards) and the browser (menus, buttons).
// Keys, labels and role presets are identical to the Laravel v2.0.0 build so imported users keep their access.

export const PERMISSION_LIST = [
  { key: "search", label: "Search & compare rates", group: "Daily work" },
  { key: "quotations", label: "Create & manage quotations", group: "Daily work" },
  { key: "trips", label: "Create & manage trip packages", group: "Daily work" },
  { key: "bookings", label: "Confirm & view bookings", group: "Daily work" },
  { key: "send_email", label: "Email proposals to clients", group: "Daily work" },
  { key: "hotels", label: "Manage hotels, contacts & groups", group: "Contracts" },
  { key: "rooms", label: "Manage room types & occupancy", group: "Contracts" },
  { key: "rates", label: "Manage rates, markets & promos", group: "Contracts" },
  { key: "blackouts", label: "Manage blackout dates", group: "Contracts" },
  { key: "catalog", label: "Manage services, tours & tickets", group: "Contracts" },
  { key: "view_cost", label: "See net hotel cost & markup", group: "Commercial" },
  { key: "users", label: "Manage users & permissions", group: "Administration" },
  { key: "settings", label: "Manage SMTP, backups & system settings", group: "Administration" },
] as const;

export type Permission = (typeof PERMISSION_LIST)[number]["key"];

export const PERMISSIONS: Permission[] = PERMISSION_LIST.map((item) => item.key);

export type Role = "admin" | "manager" | "agent" | "viewer";

export const ROLE_PRESETS: Record<Role, { label: string; description: string; permissions: Permission[] }> = {
  admin: {
    label: "Administrator",
    description: "Full access including users, settings, backups and commercial margins.",
    permissions: [...PERMISSIONS],
  },
  manager: {
    label: "Manager",
    description: "Runs contracts and sees cost & markup, but cannot manage users.",
    permissions: ["search", "quotations", "trips", "bookings", "send_email", "hotels", "rooms", "rates", "blackouts", "catalog", "view_cost"],
  },
  agent: {
    label: "Reservations agent",
    description: "Sells: search, quote, package and book. Net cost and markup stay hidden.",
    permissions: ["search", "quotations", "trips", "bookings", "send_email"],
  },
  viewer: {
    label: "Viewer",
    description: "Read-only access to search and existing proposals.",
    permissions: ["search"],
  },
};

export const ROLES = Object.keys(ROLE_PRESETS) as Role[];

export type SessionUser = {
  id: number;
  name: string;
  email: string;
  role: string;
  permissions: Permission[];
  mustChangePassword: boolean;
};

export function isRole(value: unknown): value is Role {
  return typeof value === "string" && value in ROLE_PRESETS;
}

/** "search,quotations" (or an array) -> validated permission list. */
export function parsePermissions(value: unknown): Permission[] {
  const list = Array.isArray(value) ? value : String(value ?? "").split(",");
  const valid = new Set<string>(PERMISSIONS);
  return Array.from(new Set(list.map((item) => String(item).trim()).filter((item): item is Permission => valid.has(item))));
}

export function serialisePermissions(value: unknown): string {
  return parsePermissions(value).join(",");
}

export function can(user: Pick<SessionUser, "role" | "permissions"> | null | undefined, permission: Permission): boolean {
  if (!user) return false;
  if (user.role === "admin") return true;
  return user.permissions.includes(permission);
}
