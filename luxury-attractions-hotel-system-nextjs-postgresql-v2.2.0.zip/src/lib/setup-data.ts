import { db } from "@/db";
import { amenities, locations, markets, roomCategories } from "@/db/schema";
import { MARKETS, ROOM_CATEGORIES } from "@/lib/search-engine";

/**
 * Reference lists only (markets, districts, amenities, room categories) for a clean start.
 * Uses ON CONFLICT DO NOTHING, so it can never overwrite or duplicate existing records.
 */
export async function seedReferenceLists() {
  await db
    .insert(markets)
    .values([...MARKETS, { value: "drc_nationals", label: "DRC Nationals" }].map((market, index) => ({ slug: market.value, label: market.label, sortOrder: (index + 1) * 10 })))
    .onConflictDoNothing();
  await db
    .insert(locations)
    .values([
      { city: "Dubai", name: "Deira" },
      { city: "Dubai", name: "Downtown Dubai" },
      { city: "Dubai", name: "Al Barsha" },
      { city: "Dubai", name: "Palm Jumeirah" },
      { city: "Dubai", name: "Jumeirah" },
      { city: "Dubai", name: "Dubai Silicon Oasis" },
      { city: "Abu Dhabi", name: "Saadiyat Island" },
      { city: "Abu Dhabi", name: "Corniche" },
      { city: "Abu Dhabi", name: "Liwa Desert" },
      { city: "Ras Al Khaimah", name: "Marjan Island" },
      { city: "Ras Al Khaimah", name: "Al Wadi Desert" },
    ])
    .onConflictDoNothing();
  await db
    .insert(amenities)
    .values([
      { slug: "swimming_pool", label: "Swimming pool", icon: "waves", sortOrder: 10 },
      { slug: "beach", label: "Beach", icon: "umbrella", sortOrder: 20 },
      { slug: "gym", label: "Gym", icon: "dumbbell", sortOrder: 30 },
      { slug: "metro", label: "Metro nearby", icon: "train", sortOrder: 40 },
    ])
    .onConflictDoNothing();
  await db
    .insert(roomCategories)
    .values(ROOM_CATEGORIES.map((category, index) => ({ slug: category.value, label: category.label, sortOrder: (index + 1) * 10 })))
    .onConflictDoNothing();
}
