"use client";

import { FormEvent, useState } from "react";
import { CheckCircle2, Database, FileUp, Loader2, PackageOpen, Rocket, ShieldCheck, Sparkles } from "lucide-react";

type Start = "sample" | "empty" | "import";

export default function SetupForm({ existing }: { existing: { label: string; count: number }[] }) {
  const hasData = existing.length > 0;
  const [start, setStart] = useState<Start>("sample");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState("");

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    form.set("start", hasData ? "keep" : start);
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/setup", { method: "POST", body: form });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Setup failed.");
      setDone(data.message || "Setup complete.");
      setTimeout(() => { window.location.href = "/"; }, 1200);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Setup failed.");
      setBusy(false);
    }
  };

  const input = "mt-1 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm outline-none transition focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10";
  const options: { id: Start; title: string; copy: string; icon: typeof Sparkles }[] = [
    { id: "sample", title: "Sample catalogue", copy: "14 demo hotels with rooms, rates, quotations and a trip package — ideal for trying things out.", icon: Sparkles },
    { id: "empty", title: "Start empty", copy: "Only reference lists (markets, districts, amenities, room categories). Add your own contracts.", icon: PackageOpen },
    { id: "import", title: "Import my existing data", copy: "Bring everything over from the Laravel/MySQL system or a backup file.", icon: FileUp },
  ];

  if (done) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-6 text-emerald-900">
        <div className="flex items-center gap-2 text-lg font-extrabold"><CheckCircle2 size={22} /> Setup complete</div>
        <p className="mt-2 text-sm">{done}</p>
        <p className="mt-1 text-xs text-emerald-700">Opening the dashboard…</p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5">
      {error && <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-semibold text-rose-700">{error}</p>}

      <section className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm">
        <h2 className="text-sm font-extrabold uppercase tracking-wider text-slate-400">1 · Administrator</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <label className="text-xs font-bold text-slate-600">Full name<input name="name" required className={input} /></label>
          <label className="text-xs font-bold text-slate-600">Email<input name="email" type="email" required autoComplete="email" className={input} /></label>
          <label className="text-xs font-bold text-slate-600">Password (min. 8 characters)<input name="password" type="password" required minLength={8} autoComplete="new-password" className={input} /></label>
          <label className="text-xs font-bold text-slate-600">Repeat password<input name="confirm" type="password" required minLength={8} autoComplete="new-password" className={input} /></label>
          <label className="text-xs font-bold text-slate-600 sm:col-span-2">Phone / WhatsApp (optional)<input name="phone" className={input} /></label>
        </div>
        <p className="mt-3 text-[11px] text-slate-400">If you import staff accounts and one uses this email, that account becomes the administrator with this password.</p>
      </section>

      <section className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm">
        <h2 className="text-sm font-extrabold uppercase tracking-wider text-slate-400">2 · Data</h2>
        {hasData ? (
          <div className="mt-3 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900">
            <div className="flex items-center gap-2 font-extrabold"><ShieldCheck size={18} /> Existing data found — it will be kept exactly as it is</div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {existing.map((item) => <span key={item.label} className="rounded-full bg-white px-2.5 py-1 text-xs font-bold text-emerald-800">{item.count} {item.label.toLowerCase()}</span>)}
            </div>
            <p className="mt-2 text-xs text-emerald-800">Nothing will be seeded or overwritten. Only the administrator account is created.</p>
          </div>
        ) : (
          <>
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              {options.map((option) => {
                const Icon = option.icon;
                return (
                  <button type="button" key={option.id} onClick={() => setStart(option.id)} className={`rounded-xl border p-4 text-left transition ${start === option.id ? "border-teal-600 bg-teal-50/60 ring-2 ring-teal-700/10" : "border-slate-200 hover:bg-slate-50"}`}>
                    <Icon size={18} className="text-teal-700" />
                    <div className="mt-2 text-sm font-extrabold text-slate-900">{option.title}</div>
                    <div className="mt-1 text-[11px] leading-4 text-slate-500">{option.copy}</div>
                  </button>
                );
              })}
            </div>
            {start === "import" && (
              <div className="mt-4 rounded-xl border border-dashed border-teal-300 bg-teal-50/40 p-4">
                <label className="flex items-center gap-2 text-xs font-bold text-slate-700"><Database size={15} /> Export file (.sql from phpMyAdmin, /api/bootstrap .json, or a backup .json)</label>
                <input name="file" type="file" required accept=".json,.sql,.txt" className="mt-2 block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-white file:px-3 file:py-2 file:text-sm file:font-bold file:text-teal-800" />
                <ul className="mt-3 list-disc space-y-1 pl-5 text-[11px] leading-4 text-slate-600">
                  <li><b>phpMyAdmin:</b> cPanel → phpMyAdmin → your hotels database → Export → Quick → SQL. Includes staff passwords and SMTP.</li>
                  <li><b>Live system:</b> sign in to hotels.luxuryattractions.com and save <code>/api/bootstrap</code> as a .json file (staff passwords not included).</li>
                  <li>Your MySQL database is only read — nothing there is changed.</li>
                </ul>
              </div>
            )}
          </>
        )}
      </section>

      <button disabled={busy} className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#174e48] text-sm font-bold text-white shadow-sm transition hover:bg-[#103f3a] disabled:opacity-60">
        {busy ? <Loader2 size={18} className="animate-spin" /> : <Rocket size={18} />} {busy ? "Setting up…" : "Finish setup"}
      </button>
    </form>
  );
}
