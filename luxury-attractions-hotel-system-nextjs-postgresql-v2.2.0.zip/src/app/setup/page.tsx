import { redirect } from "next/navigation";
import AuthShell from "../auth-shell";
import SetupForm from "./setup-form";
import { hasAnyUser } from "@/lib/auth";
import { getTableCounts, TABLE_LABELS } from "@/lib/backup";

export const dynamic = "force-dynamic";

export default async function SetupPage() {
  if (await hasAnyUser()) redirect("/login");
  const counts = await getTableCounts();
  const existing = Object.entries(counts)
    .filter(([table, count]) => count > 0 && table !== "users" && table !== "smtp_settings")
    .map(([table, count]) => ({ label: TABLE_LABELS[table] ?? table, count }));
  return (
    <AuthShell title="Set up the hotel system" subtitle="Create the administrator account and choose how to start. This screen is only shown once." wide>
      <SetupForm existing={existing} />
    </AuthShell>
  );
}
