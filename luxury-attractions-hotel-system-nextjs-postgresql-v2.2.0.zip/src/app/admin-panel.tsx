"use client";

import { FormEvent, ReactNode, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  AlertTriangle, CheckCircle2, Database, Download, FileUp, History, Info, KeyRound, Loader2, Mail, Pencil,
  Plus, RotateCcw, Save, Send, ShieldCheck, Trash2, Users, X,
} from "lucide-react";
import type { AdminData, AdminUser, ImportReport, SnapshotInfo } from "@/lib/admin-types";
import { screenHref } from "@/lib/links";
import { can, PERMISSION_LIST, Permission, Role, ROLE_PRESETS, ROLES, SessionUser } from "@/lib/permissions";

type Notify = (type: "success" | "error", message: string) => void;
type TabId = "users" | "backups" | "email";

const input = "h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none transition focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10 disabled:bg-slate-50 disabled:text-slate-400";
const primary = "inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white shadow-sm transition hover:bg-[#103f3a] disabled:opacity-50";
const secondary = "inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition hover:bg-slate-50 disabled:opacity-50";
const card = "rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm";

const fmtDateTime = (iso: string | null) =>
  iso ? `${new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "UTC" }).format(new Date(iso))} UTC` : "Never";
const fmtSize = (bytes: number) => (bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`);
const KIND_LABEL: Record<string, { label: string; tone: string }> = {
  auto: { label: "Daily", tone: "bg-sky-50 text-sky-700" },
  manual: { label: "Manual", tone: "bg-teal-50 text-teal-700" },
  "pre-import": { label: "Safety copy", tone: "bg-amber-50 text-amber-700" },
};

async function callApi<T = Record<string, unknown>>(url: string, init: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error((data as { error?: string }).error || "Request failed.");
  return data as T;
}

function Modal({ title, subtitle, onClose, children, wide }: { title: string; subtitle?: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/50 p-4" role="dialog" aria-modal="true">
      <div className={`flex max-h-[92vh] w-full flex-col overflow-hidden rounded-2xl bg-white shadow-2xl ${wide ? "max-w-3xl" : "max-w-lg"}`}>
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-950">{title}</h2>
            {subtitle && <p className="mt-0.5 text-xs text-slate-500">{subtitle}</p>}
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100" aria-label="Close"><X size={18} /></button>
        </div>
        <div className="overflow-y-auto px-6 py-5">{children}</div>
      </div>
    </div>
  );
}

export default function AdminPanel({ admin, currentUser, notify, initialTab = "" }: { admin: AdminData; currentUser: SessionUser; notify: Notify; initialTab?: string }) {
  const tabs: { id: TabId; label: string; icon: typeof Users }[] = [];
  if (can(currentUser, "users")) tabs.push({ id: "users", label: "Users & permissions", icon: Users });
  if (can(currentUser, "settings")) {
    tabs.push({ id: "backups", label: "Data & backups", icon: Database });
    tabs.push({ id: "email", label: "Email (SMTP)", icon: Mail });
  }
  const [tab, setTab] = useState<TabId>(() => tabs.find((item) => item.id === initialTab)?.id ?? tabs[0]?.id ?? "users");
  useEffect(() => {
    if (initialTab && initialTab !== tab) window.history.replaceState(null, "", screenHref("admin", tab));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (tabs.length === 0) return <p className={card}>You do not have access to administration.</p>;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2">
        {tabs.map((item) => {
          const Icon = item.icon;
          return (
            <button key={item.id} onClick={() => { setTab(item.id); window.history.replaceState(null, "", screenHref("admin", item.id)); }} className={`inline-flex h-10 items-center gap-2 rounded-xl px-4 text-sm font-bold transition ${tab === item.id ? "bg-[#174e48] text-white shadow-sm" : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}>
              <Icon size={16} /> {item.label}
            </button>
          );
        })}
      </div>
      {tab === "users" && <UsersSection users={admin.users} currentUser={currentUser} notify={notify} />}
      {tab === "backups" && <BackupsSection admin={admin} notify={notify} />}
      {tab === "email" && <SmtpSection admin={admin} currentUser={currentUser} notify={notify} />}
    </div>
  );
}

/* ------------------------------------------------------------------ users --- */

function UsersSection({ users, currentUser, notify }: { users: AdminUser[]; currentUser: SessionUser; notify: Notify }) {
  const router = useRouter();
  const [editing, setEditing] = useState<AdminUser | "new" | null>(null);
  const remove = async (user: AdminUser) => {
    if (!window.confirm(`Delete ${user.name} (${user.email})? This cannot be undone — consider disabling the account instead.`)) return;
    try {
      await callApi(`/api/users?id=${user.id}`, { method: "DELETE" });
      notify("success", `${user.name} removed.`);
      router.refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Unable to delete user.");
    }
  };
  return (
    <div className={card}>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-extrabold text-slate-950">Staff accounts</h2>
          <p className="text-xs text-slate-500">Roles set sensible defaults; tick individual permissions to fine-tune access.</p>
        </div>
        <button onClick={() => setEditing("new")} className={primary}><Plus size={16} /> Add user</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-slate-100 text-left text-[11px] font-bold uppercase tracking-wider text-slate-400">
              <th className="py-2 pr-3">User</th><th className="py-2 pr-3">Role</th><th className="py-2 pr-3">Access</th><th className="py-2 pr-3">Status</th><th className="py-2 pr-3">Last sign-in</th><th className="py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="border-b border-slate-50 last:border-0">
                <td className="py-3 pr-3">
                  <div className="font-bold text-slate-900">{user.name} {user.id === currentUser.id && <span className="ml-1 rounded-full bg-teal-50 px-2 py-0.5 text-[10px] font-bold text-teal-700">You</span>}</div>
                  <div className="text-xs text-slate-500">{user.email}{user.phone ? ` · ${user.phone}` : ""}</div>
                </td>
                <td className="py-3 pr-3 font-semibold text-slate-700">{ROLE_PRESETS[user.role as Role]?.label ?? user.role}</td>
                <td className="py-3 pr-3 text-xs text-slate-500">{user.role === "admin" ? "Everything" : `${user.permissions.length} permission${user.permissions.length === 1 ? "" : "s"}`}</td>
                <td className="py-3 pr-3">
                  <span className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${user.active ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>{user.active ? "Active" : "Disabled"}</span>
                  {user.mustChangePassword && <span className="ml-1 rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-bold text-amber-700">Must set password</span>}
                </td>
                <td className="py-3 pr-3 text-xs text-slate-500">{fmtDateTime(user.lastLoginAt)}</td>
                <td className="py-3 text-right">
                  <button onClick={() => setEditing(user)} className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50" title="Edit"><Pencil size={14} /></button>
                  {user.id !== currentUser.id && <button onClick={() => void remove(user)} className="ml-1.5 rounded-lg border border-rose-200 p-2 text-rose-600 hover:bg-rose-50" title="Delete"><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {editing && <UserDialog user={editing === "new" ? null : editing} onClose={() => setEditing(null)} notify={notify} />}
    </div>
  );
}

function UserDialog({ user, onClose, notify }: { user: AdminUser | null; onClose: () => void; notify: Notify }) {
  const router = useRouter();
  const [role, setRole] = useState<Role>((user?.role as Role) in ROLE_PRESETS ? (user!.role as Role) : "agent");
  const [permissions, setPermissions] = useState<Set<Permission>>(new Set((user?.permissions as Permission[]) ?? ROLE_PRESETS.agent.permissions));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const groups = Array.from(new Set(PERMISSION_LIST.map((item) => item.group)));

  const pickRole = (next: Role) => {
    setRole(next);
    setPermissions(new Set(ROLE_PRESETS[next].permissions));
  };
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setSaving(true);
    setError("");
    const payload = {
      name: form.get("name"),
      phone: form.get("phone"),
      role,
      permissions: role === "admin" ? ROLE_PRESETS.admin.permissions : Array.from(permissions),
      password: String(form.get("password") || "") || undefined,
    };
    try {
      await callApi("/api/users", {
        method: user ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user ? { ...payload, id: user.id, active: form.get("active") === "on" } : { ...payload, email: form.get("email") }),
      });
      notify("success", user ? "User updated." : "User created.");
      onClose();
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save user.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={user ? `Edit ${user.name}` : "Add user"} subtitle="Roles set a sensible default; tick individual permissions to fine-tune access." onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        {error && <p className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-semibold text-rose-700">{error}</p>}
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-xs font-bold text-slate-600">Full name<input name="name" required defaultValue={user?.name} className={`${input} mt-1`} /></label>
          <label className="text-xs font-bold text-slate-600">Email<input name="email" type="email" required={!user} disabled={Boolean(user)} defaultValue={user?.email} className={`${input} mt-1`} /></label>
          <label className="text-xs font-bold text-slate-600">Phone / WhatsApp<input name="phone" defaultValue={user?.phone} className={`${input} mt-1`} /></label>
          <label className="text-xs font-bold text-slate-600">{user ? "New password (leave blank to keep)" : "Temporary password"}<input name="password" type="password" minLength={8} required={!user} autoComplete="new-password" className={`${input} mt-1`} /></label>
        </div>
        <div>
          <p className="mb-2 text-xs font-bold text-slate-600">Role</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {ROLES.map((key) => (
              <button type="button" key={key} onClick={() => pickRole(key)} className={`rounded-xl border p-3 text-left transition ${role === key ? "border-teal-600 bg-teal-50/60 ring-2 ring-teal-700/10" : "border-slate-200 hover:bg-slate-50"}`}>
                <div className="text-sm font-extrabold text-slate-900">{ROLE_PRESETS[key].label}</div>
                <div className="mt-0.5 text-[11px] leading-4 text-slate-500">{ROLE_PRESETS[key].description}</div>
              </button>
            ))}
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {groups.map((group) => (
            <fieldset key={group} className="rounded-xl border border-slate-100 p-3">
              <legend className="px-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">{group}</legend>
              {PERMISSION_LIST.filter((item) => item.group === group).map((item) => (
                <label key={item.key} className="flex items-center gap-2 py-1 text-sm text-slate-700">
                  <input
                    type="checkbox"
                    className="h-4 w-4 accent-teal-700"
                    disabled={role === "admin"}
                    checked={role === "admin" || permissions.has(item.key)}
                    onChange={(event) => {
                      const next = new Set(permissions);
                      if (event.target.checked) next.add(item.key);
                      else next.delete(item.key);
                      setPermissions(next);
                    }}
                  />
                  {item.label}
                </label>
              ))}
            </fieldset>
          ))}
        </div>
        {user && (
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <input type="checkbox" name="active" defaultChecked={user.active} className="h-4 w-4 accent-teal-700" /> Account active (disabled users cannot sign in)
          </label>
        )}
        <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
          <button type="button" onClick={onClose} className={secondary}>Cancel</button>
          <button disabled={saving} className={primary}>{saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} Save user</button>
        </div>
      </form>
    </Modal>
  );
}

/* ---------------------------------------------------------------- backups --- */

function ReportTable({ report }: { report: ImportReport }) {
  const after = (row: ImportReport["tables"][number]) => {
    if (!report.dryRun) return report.mode === "replace" ? row.inserted : row.current + row.inserted;
    if (report.mode === "replace") return row.inFile ? row.incoming : 0;
    return `${row.current} + up to ${row.incoming}`;
  };
  const rows = report.tables.filter((row) => row.current > 0 || row.incoming > 0);
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2 text-xs">
        <span className="rounded-full bg-slate-100 px-2.5 py-1 font-bold text-slate-600">Source: {report.source}</span>
        <span className={`rounded-full px-2.5 py-1 font-bold ${report.mode === "replace" ? "bg-amber-50 text-amber-700" : "bg-teal-50 text-teal-700"}`}>{report.mode === "replace" ? "Replace everything" : "Merge — add missing only"}</span>
        {report.snapshotId && <span className="rounded-full bg-emerald-50 px-2.5 py-1 font-bold text-emerald-700">Safety copy #{report.snapshotId} saved first</span>}
      </div>
      <div className="max-h-72 overflow-y-auto rounded-xl border border-slate-100">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-slate-50">
            <tr className="text-left text-[11px] font-bold uppercase tracking-wider text-slate-400">
              <th className="px-3 py-2">Data</th><th className="px-3 py-2 text-right">Now</th><th className="px-3 py-2 text-right">In file</th><th className="px-3 py-2 text-right">{report.dryRun ? "After import" : "Result"}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.table} className="border-t border-slate-50">
                <td className="px-3 py-1.5 font-semibold text-slate-700">{row.label}</td>
                <td className="px-3 py-1.5 text-right text-slate-500">{row.current}</td>
                <td className="px-3 py-1.5 text-right text-slate-500">{row.inFile ? row.incoming : "—"}</td>
                <td className="px-3 py-1.5 text-right font-bold text-slate-900">{after(row)}</td>
              </tr>
            ))}
            <tr className="border-t border-slate-100 bg-slate-50/60">
              <td className="px-3 py-1.5 font-semibold text-slate-700">Staff accounts (matched by email, never deleted)</td>
              <td className="px-3 py-1.5" />
              <td className="px-3 py-1.5 text-right text-slate-500">{report.users.incoming}</td>
              <td className="px-3 py-1.5 text-right text-xs font-bold text-slate-900">{report.dryRun ? "added / updated" : `${report.users.created} added · ${report.users.updated} updated`}</td>
            </tr>
          </tbody>
        </table>
      </div>
      {report.warnings.length > 0 && (
        <ul className="space-y-1 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs font-semibold text-amber-800">
          {report.warnings.map((warning) => <li key={warning} className="flex gap-2"><AlertTriangle size={14} className="mt-0.5 shrink-0" /> {warning}</li>)}
        </ul>
      )}
      {report.ignored.length > 0 && <p className="text-xs text-slate-400">Ignored (not part of this system): {report.ignored.join(", ")}</p>}
    </div>
  );
}

function BackupsSection({ admin, notify }: { admin: AdminData; notify: Notify }) {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [mode, setMode] = useState<"replace" | "merge">("replace");
  const [busy, setBusy] = useState("");
  const [preview, setPreview] = useState<{ report: ImportReport; restoreId?: number } | null>(null);
  const [result, setResult] = useState<ImportReport | null>(null);
  const [note, setNote] = useState("");
  const counts = admin.counts;
  const stats: [string, string][] = [["Hotels", "hotels"], ["Room types", "room_types"], ["Rate periods", "rate_periods"], ["Quotations", "quotations"], ["Bookings", "bookings"], ["Trip packages", "trip_packages"], ["Users", "users"]];
  const total = Object.entries(counts).filter(([table]) => table !== "users" && table !== "smtp_settings").reduce((sum, [, value]) => sum + value, 0);

  const runFileImport = async (dryRun: boolean) => {
    if (!file) return;
    setBusy(dryRun ? "preview" : "import");
    try {
      const form = new FormData();
      form.set("file", file);
      form.set("mode", mode);
      form.set("dryRun", dryRun ? "1" : "0");
      const { report } = await callApi<{ report: ImportReport }>("/api/backup", { method: "POST", body: form });
      if (dryRun) setPreview({ report });
      else {
        setPreview(null);
        setResult(report);
        setFile(null);
        notify("success", "Import complete. A safety copy of the previous data was saved first.");
        router.refresh();
      }
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Import failed.");
    } finally {
      setBusy("");
    }
  };

  const runRestore = async (id: number, dryRun: boolean) => {
    setBusy(dryRun ? `restore-${id}` : "import");
    try {
      const { report } = await callApi<{ report: ImportReport }>("/api/backup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "restore", id, dryRun }) });
      if (dryRun) setPreview({ report, restoreId: id });
      else {
        setPreview(null);
        setResult(report);
        notify("success", `Restore point #${id} restored. The data before the restore was saved as a safety copy.`);
        router.refresh();
      }
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Restore failed.");
    } finally {
      setBusy("");
    }
  };

  const createPoint = async () => {
    setBusy("snapshot");
    try {
      await callApi("/api/backup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "snapshot", note }) });
      setNote("");
      notify("success", "Restore point created.");
      router.refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Unable to create restore point.");
    } finally {
      setBusy("");
    }
  };

  const removePoint = async (snapshot: SnapshotInfo) => {
    if (!window.confirm(`Delete restore point #${snapshot.id} from ${fmtDateTime(snapshot.createdAt)}?`)) return;
    try {
      await callApi(`/api/backup?id=${snapshot.id}`, { method: "DELETE" });
      notify("success", "Restore point deleted.");
      router.refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Unable to delete.");
    }
  };

  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4 text-sm text-emerald-900">
        <div className="flex items-center gap-2 font-extrabold"><ShieldCheck size={18} /> Your data is protected</div>
        <ul className="mt-2 grid gap-1 text-xs leading-5 sm:grid-cols-2">
          <li>• Updates never delete or reseed data — sample data is only added once, at setup.</li>
          <li>• A restore point is saved automatically every day (last: {fmtDateTime(admin.lastAutoSnapshot)}).</li>
          <li>• Every import or restore saves a safety copy first and runs all-or-nothing.</li>
          <li>• Download a full backup any time — it also imports into the Laravel build.</li>
        </ul>
      </div>

      <div className="grid gap-3 sm:grid-cols-4 lg:grid-cols-8">
        <div className="rounded-2xl bg-[#173f3b] p-4 text-white sm:col-span-4 lg:col-span-1"><div className="text-[11px] font-bold uppercase tracking-wider text-teal-100/80">Records</div><div className="mt-1 text-2xl font-extrabold">{total}</div></div>
        {stats.map(([label, key]) => (
          <div key={key} className="rounded-2xl border border-slate-200/80 bg-white p-4"><div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">{label}</div><div className="mt-1 text-xl font-extrabold text-slate-900">{counts[key] ?? 0}</div></div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className={card}>
          <h3 className="flex items-center gap-2 text-base font-extrabold text-slate-950"><Download size={18} className="text-teal-700" /> Download full backup</h3>
          <p className="mt-1 text-xs leading-5 text-slate-500">Every hotel, room, rate, contact, quotation, booking, trip package, user and setting as one JSON file. Keep it somewhere safe before making changes — it contains confidential data.</p>
          <a href="/api/backup?download=full" className={`${primary} mt-4`}><Download size={16} /> Download backup (.json)</a>
          <div className="mt-5 border-t border-slate-100 pt-4">
            <h4 className="text-sm font-extrabold text-slate-900">Create a restore point now</h4>
            <p className="mt-0.5 text-xs text-slate-500">Saved inside the database — one click to roll back later.</p>
            <div className="mt-2 flex gap-2">
              <input value={note} onChange={(event) => setNote(event.target.value)} placeholder="Note, e.g. Before 2027 rate update" className={input} />
              <button onClick={() => void createPoint()} disabled={busy === "snapshot"} className={secondary}>{busy === "snapshot" ? <Loader2 size={16} className="animate-spin" /> : <History size={16} />} Save</button>
            </div>
          </div>
        </div>

        <div className={card}>
          <h3 className="flex items-center gap-2 text-base font-extrabold text-slate-950"><FileUp size={18} className="text-teal-700" /> Import data</h3>
          <p className="mt-1 text-xs leading-5 text-slate-500">Accepts a backup from this system, a phpMyAdmin <b>.sql</b> export of the Laravel/MySQL database, or the JSON saved from <b>/api/bootstrap</b> of the live system. You will see a preview first.</p>
          <input type="file" accept=".json,.sql,.txt,application/json,application/sql" onChange={(event) => { setFile(event.target.files?.[0] ?? null); setPreview(null); setResult(null); }} className="mt-3 block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-teal-50 file:px-3 file:py-2 file:text-sm file:font-bold file:text-teal-800 hover:file:bg-teal-100" />
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <label className={`cursor-pointer rounded-xl border p-3 text-xs ${mode === "replace" ? "border-teal-600 bg-teal-50/50" : "border-slate-200"}`}>
              <input type="radio" name="mode" className="mr-1.5 accent-teal-700" checked={mode === "replace"} onChange={() => setMode("replace")} />
              <b className="text-slate-900">Replace everything</b>
              <span className="mt-1 block text-slate-500">Contracts & sales data become exactly what is in the file (moving from Laravel, full restore).</span>
            </label>
            <label className={`cursor-pointer rounded-xl border p-3 text-xs ${mode === "merge" ? "border-teal-600 bg-teal-50/50" : "border-slate-200"}`}>
              <input type="radio" name="mode" className="mr-1.5 accent-teal-700" checked={mode === "merge"} onChange={() => setMode("merge")} />
              <b className="text-slate-900">Merge — add missing only</b>
              <span className="mt-1 block text-slate-500">Only records whose id is free are added. Existing records are never changed.</span>
            </label>
          </div>
          <button onClick={() => void runFileImport(true)} disabled={!file || Boolean(busy)} className={`${primary} mt-4`}>{busy === "preview" ? <Loader2 size={16} className="animate-spin" /> : <Info size={16} />} Preview import</button>
        </div>
      </div>

      {result && (
        <div className={`${card} border-emerald-200`}>
          <h3 className="mb-3 flex items-center gap-2 text-base font-extrabold text-emerald-800"><CheckCircle2 size={18} /> Completed</h3>
          <ReportTable report={result} />
        </div>
      )}

      <div className={card}>
        <h3 className="flex items-center gap-2 text-base font-extrabold text-slate-950"><Info size={18} className="text-teal-700" /> Moving your data from the Laravel / MySQL system</h3>
        <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-xs leading-5 text-slate-600">
          <li><b>Easiest:</b> sign in at hotels.luxuryattractions.com, open <code className="rounded bg-slate-100 px-1">https://hotels.luxuryattractions.com/api/bootstrap</code> and save the page as a <b>.json</b> file (Ctrl+S). Contains all business data; staff passwords are not included, so set them again under Users.</li>
          <li><b>Complete:</b> cPanel → phpMyAdmin → select the hotels database → <b>Export</b> → Quick → Format <b>SQL</b> → Export. Includes staff passwords (bcrypt — they keep working here) and SMTP settings.</li>
          <li>Upload the file above, choose <b>Replace everything</b>, check the preview, then confirm. Your MySQL database is only read, never changed.</li>
        </ol>
      </div>

      <div className={card}>
        <h3 className="mb-3 flex items-center gap-2 text-base font-extrabold text-slate-950"><History size={18} className="text-teal-700" /> Restore points</h3>
        {admin.snapshots.length === 0 ? (
          <p className="text-sm text-slate-500">No restore points yet. The first daily one is created automatically.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-slate-100 text-left text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  <th className="py-2 pr-3">#</th><th className="py-2 pr-3">Saved</th><th className="py-2 pr-3">Type</th><th className="py-2 pr-3">Note</th><th className="py-2 pr-3 text-right">Records</th><th className="py-2 pr-3 text-right">Size</th><th className="py-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {admin.snapshots.map((snapshot) => {
                  const kind = KIND_LABEL[snapshot.kind] ?? { label: snapshot.kind, tone: "bg-slate-100 text-slate-600" };
                  return (
                    <tr key={snapshot.id} className="border-b border-slate-50 last:border-0">
                      <td className="py-2.5 pr-3 font-bold text-slate-400">{snapshot.id}</td>
                      <td className="py-2.5 pr-3 text-xs text-slate-600">{fmtDateTime(snapshot.createdAt)}<div className="text-slate-400">{snapshot.createdBy}</div></td>
                      <td className="py-2.5 pr-3"><span className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${kind.tone}`}>{kind.label}</span></td>
                      <td className="max-w-[260px] truncate py-2.5 pr-3 text-xs text-slate-600" title={snapshot.note}>{snapshot.note}</td>
                      <td className="py-2.5 pr-3 text-right font-semibold text-slate-700">{snapshot.rowCount}</td>
                      <td className="py-2.5 pr-3 text-right text-xs text-slate-500">{fmtSize(snapshot.sizeBytes)}</td>
                      <td className="whitespace-nowrap py-2.5 text-right">
                        <a href={`/api/backup?snapshot=${snapshot.id}`} className="inline-flex rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50" title="Download"><Download size={14} /></a>
                        <button onClick={() => void runRestore(snapshot.id, true)} disabled={Boolean(busy)} className="ml-1.5 inline-flex rounded-lg border border-teal-200 p-2 text-teal-700 hover:bg-teal-50" title="Restore">{busy === `restore-${snapshot.id}` ? <Loader2 size={14} className="animate-spin" /> : <RotateCcw size={14} />}</button>
                        <button onClick={() => void removePoint(snapshot)} className="ml-1.5 inline-flex rounded-lg border border-rose-200 p-2 text-rose-600 hover:bg-rose-50" title="Delete"><Trash2 size={14} /></button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {preview && (
        <Modal title={preview.restoreId ? `Restore point #${preview.restoreId} — preview` : "Import preview"} subtitle="Nothing has been changed yet. Review the numbers, then confirm." onClose={() => setPreview(null)} wide>
          <ReportTable report={preview.report} />
          <p className="mt-3 rounded-xl bg-slate-50 p-3 text-xs text-slate-600">A safety copy of the current data is saved automatically before anything changes, and the whole operation is all-or-nothing. You can roll back from Restore points at any time.</p>
          <div className="mt-4 flex justify-end gap-2">
            <button onClick={() => setPreview(null)} className={secondary}>Cancel</button>
            <button onClick={() => void (preview.restoreId ? runRestore(preview.restoreId, false) : runFileImport(false))} disabled={busy === "import"} className={primary}>
              {busy === "import" ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle2 size={16} />} {preview.restoreId ? "Restore now" : "Confirm import"}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------- smtp --- */

function SmtpSection({ admin, currentUser, notify }: { admin: AdminData; currentUser: SessionUser; notify: Notify }) {
  const router = useRouter();
  const smtp = admin.smtp;
  const [busy, setBusy] = useState("");
  const save = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setBusy("save");
    try {
      await callApi("/api/email", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          host: form.get("host"), port: Number(form.get("port")) || 587, secure: form.get("secure") === "true", username: form.get("username"),
          password: form.get("password"), fromName: form.get("fromName"), fromEmail: form.get("fromEmail"), replyTo: form.get("replyTo"),
          bccSelf: form.get("bccSelf") === "on", active: form.get("active") === "on",
        }),
      });
      notify("success", "SMTP settings saved.");
      router.refresh();
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Unable to save SMTP settings.");
    } finally {
      setBusy("");
    }
  };
  const test = async () => {
    setBusy("test");
    try {
      const data = await callApi<{ message?: string }>("/api/email", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "test", to: currentUser.email }) });
      notify("success", data.message || "Test email sent.");
    } catch (error) {
      notify("error", error instanceof Error ? error.message : "Test email failed.");
    } finally {
      setBusy("");
    }
  };
  return (
    <form onSubmit={save} className={card}>
      <h2 className="text-base font-extrabold text-slate-950">SMTP account used to email proposals</h2>
      <p className="mb-4 text-xs text-slate-500">cPanel mail: host <b>mail.luxuryattractions.com</b>, port 465 with SSL (or 587 with STARTTLS), username = full mailbox address.</p>
      <div className="grid gap-3 sm:grid-cols-3">
        <label className="text-xs font-bold text-slate-600 sm:col-span-2">SMTP host<input name="host" required defaultValue={smtp?.host} placeholder="mail.luxuryattractions.com" className={`${input} mt-1`} /></label>
        <label className="text-xs font-bold text-slate-600">Port<input name="port" type="number" defaultValue={smtp?.port ?? 587} className={`${input} mt-1`} /></label>
        <label className="text-xs font-bold text-slate-600">Security<select name="secure" defaultValue={smtp?.secure ? "true" : "false"} className={`${input} mt-1`}><option value="false">STARTTLS / none (587, 25)</option><option value="true">SSL/TLS (465)</option></select></label>
        <label className="text-xs font-bold text-slate-600">Username<input name="username" defaultValue={smtp?.username} autoComplete="off" className={`${input} mt-1`} /></label>
        <label className="text-xs font-bold text-slate-600">Password<input name="password" type="password" autoComplete="new-password" placeholder={smtp?.password ? "•••••••• (unchanged)" : ""} className={`${input} mt-1`} /></label>
        <label className="text-xs font-bold text-slate-600">From name<input name="fromName" defaultValue={smtp?.fromName ?? "Luxury Attractions"} className={`${input} mt-1`} /></label>
        <label className="text-xs font-bold text-slate-600">From email<input name="fromEmail" type="email" required defaultValue={smtp?.fromEmail} className={`${input} mt-1`} /></label>
        <label className="text-xs font-bold text-slate-600">Reply-to (optional)<input name="replyTo" type="email" defaultValue={smtp?.replyTo} className={`${input} mt-1`} /></label>
      </div>
      <div className="mt-4 flex flex-wrap gap-5">
        <label className="flex items-center gap-2 text-sm font-semibold text-slate-700"><input type="checkbox" name="active" defaultChecked={smtp?.active ?? true} className="h-4 w-4 accent-teal-700" /> Email sending enabled</label>
        <label className="flex items-center gap-2 text-sm font-semibold text-slate-700"><input type="checkbox" name="bccSelf" defaultChecked={smtp?.bccSelf} className="h-4 w-4 accent-teal-700" /> Bcc the from-address on every email</label>
      </div>
      <div className="mt-5 flex flex-wrap justify-end gap-2 border-t border-slate-100 pt-4">
        <button type="button" onClick={() => void test()} disabled={Boolean(busy) || !smtp} className={secondary}>{busy === "test" ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />} Send test to {currentUser.email}</button>
        <button disabled={Boolean(busy)} className={primary}>{busy === "save" ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} Save settings</button>
      </div>
    </form>
  );
}

/* -------------------------------------------------------- change password --- */

export function ChangePasswordDialog({ forced, onClose, notify }: { forced: boolean; onClose: () => void; notify: Notify }) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    if (form.get("newPassword") !== form.get("confirm")) {
      setError("The two new passwords do not match.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await callApi("/api/auth", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "change-password", currentPassword: form.get("currentPassword"), newPassword: form.get("newPassword") }) });
      notify("success", "Password changed.");
      onClose();
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to change password.");
    } finally {
      setSaving(false);
    }
  };
  return (
    <Modal title="Change password" subtitle={forced ? "Your administrator set a temporary password — choose your own to continue." : "Use at least 8 characters."} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        {error && <p className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-semibold text-rose-700">{error}</p>}
        <label className="block text-xs font-bold text-slate-600">Current password<input name="currentPassword" type="password" required autoComplete="current-password" className={`${input} mt-1`} /></label>
        <label className="block text-xs font-bold text-slate-600">New password<input name="newPassword" type="password" required minLength={8} autoComplete="new-password" className={`${input} mt-1`} /></label>
        <label className="block text-xs font-bold text-slate-600">Repeat new password<input name="confirm" type="password" required minLength={8} autoComplete="new-password" className={`${input} mt-1`} /></label>
        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className={secondary}>{forced ? "Later" : "Cancel"}</button>
          <button disabled={saving} className={primary}>{saving ? <Loader2 size={16} className="animate-spin" /> : <KeyRound size={16} />} Change password</button>
        </div>
      </form>
    </Modal>
  );
}
