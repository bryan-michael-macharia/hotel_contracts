import { redirect } from "next/navigation";
import { after } from "next/server";
import { asc } from "drizzle-orm";
import DashboardClient, { DashboardData } from "./dashboard-client";
import { db } from "@/db";
import { smtpSettings, users } from "@/db/schema";
import type { AdminData } from "@/lib/admin-types";
import { getCurrentUser, hasAnyUser } from "@/lib/auth";
import { APP_VERSION, autoSnapshotIfDue, getSetting, getTableCounts, listSnapshots } from "@/lib/backup";
import { getHotelDashboardData } from "@/lib/hotel-data";
import { screenHref } from "@/lib/links";
import { can, parsePermissions } from "@/lib/permissions";
import { searchAllHotels } from "@/lib/search-data";
import { addDays, CoreCriteria, DEFAULT_CRITERIA } from "@/lib/search-engine";

export const dynamic = "force-dynamic";

async function loadAdminData(user: NonNullable<Awaited<ReturnType<typeof getCurrentUser>>>): Promise<AdminData> {
  const manageUsers = can(user, "users");
  const manageSettings = can(user, "settings");
  const [userRows, smtpRows, snapshots, counts, lastImport, lastAutoSnapshot] = await Promise.all([
    manageUsers ? db.select().from(users).orderBy(asc(users.name)) : Promise.resolve([]),
    manageSettings ? db.select().from(smtpSettings).orderBy(asc(smtpSettings.id)).limit(1) : Promise.resolve([]),
    manageSettings ? listSnapshots() : Promise.resolve([]),
    manageSettings ? getTableCounts() : Promise.resolve({}),
    manageSettings ? getSetting("last_import") : Promise.resolve(null),
    manageSettings ? getSetting("last_auto_snapshot_at") : Promise.resolve(null),
  ]);
  const smtp = smtpRows[0];
  return {
    users: userRows.map((row) => ({
      id: row.id,
      name: row.name,
      email: row.email,
      role: row.role,
      permissions: parsePermissions(row.permissions),
      phone: row.phone,
      active: row.active,
      mustChangePassword: row.mustChangePassword,
      lastLoginAt: row.lastLoginAt ? row.lastLoginAt.toISOString() : null,
    })),
    smtp: smtp
      ? { host: smtp.host, port: smtp.port, secure: smtp.secure, username: smtp.username, password: smtp.password ? "********" : "", fromName: smtp.fromName, fromEmail: smtp.fromEmail, replyTo: smtp.replyTo, bccSelf: smtp.bccSelf, active: smtp.active }
      : null,
    snapshots,
    counts,
    lastImport,
    lastAutoSnapshot,
    version: APP_VERSION,
  };
}

export default async function HomePage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const params = await searchParams;
  const initialView = typeof params.view === "string" ? params.view : "";
  const initialTab = typeof params.tab === "string" ? params.tab : "";
  const user = await getCurrentUser();
  if (!user) {
    if (!(await hasAnyUser())) redirect("/setup");
    // Keep the requested screen, so a shared link opens it right after sign-in.
    const target = initialView ? screenHref(initialView, initialTab || undefined) : "/";
    redirect(target === "/" ? "/login" : `/login?next=${encodeURIComponent(target)}`);
  }

  const data = await getHotelDashboardData();
  const today = new Date().toISOString().slice(0, 10);
  const criteria: CoreCriteria = {
    ...DEFAULT_CRITERIA,
    checkIn: addDays(today, 14),
    checkOut: addDays(today, 17),
    bookingDate: today,
  };
  const { outsidePriceRange: _ignored, ...response } = await searchAllHotels(criteria);
  void _ignored;
  const admin = await loadAdminData(user);

  // Daily restore point, taken after the response has been sent.
  after(() => autoSnapshotIfDue(user.email));

  return (
    <DashboardClient
      data={JSON.parse(JSON.stringify(data)) as DashboardData}
      initialSearch={{ criteria, response }}
      today={today}
      currentUser={user}
      admin={JSON.parse(JSON.stringify(admin)) as AdminData}
      initialView={initialView}
      initialTab={initialTab}
    />
  );
}
