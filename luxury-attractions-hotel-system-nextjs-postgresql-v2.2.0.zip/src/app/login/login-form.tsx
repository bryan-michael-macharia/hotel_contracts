"use client";

import { FormEvent, useState } from "react";
import { Loader2, LogIn } from "lucide-react";

export default function LoginForm({ next = "/" }: { next?: string }) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "login", email: form.get("email"), password: form.get("password") }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Sign in failed.");
      window.location.href = next;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
      setBusy(false);
    }
  };
  const input = "mt-1 h-11 w-full rounded-xl border border-slate-200 bg-white px-3.5 text-sm outline-none transition focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10";
  return (
    <form onSubmit={submit} className="space-y-4 rounded-2xl border border-slate-200/80 bg-white p-6 shadow-sm">
      {error && <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-semibold text-rose-700">{error}</p>}
      <label className="block text-xs font-bold text-slate-600">Email<input name="email" type="email" required autoComplete="email" autoFocus className={input} /></label>
      <label className="block text-xs font-bold text-slate-600">Password<input name="password" type="password" required autoComplete="current-password" className={input} /></label>
      <button disabled={busy} className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#174e48] text-sm font-bold text-white shadow-sm transition hover:bg-[#103f3a] disabled:opacity-60">
        {busy ? <Loader2 size={17} className="animate-spin" /> : <LogIn size={17} />} Sign in
      </button>
      <p className="text-center text-[11px] text-slate-400">Forgot your password? Ask an administrator to set a new one under Users &amp; settings.</p>
    </form>
  );
}
