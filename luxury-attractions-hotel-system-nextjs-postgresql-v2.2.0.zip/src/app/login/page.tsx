import { redirect } from "next/navigation";
import AuthShell from "../auth-shell";
import LoginForm from "./login-form";
import { getCurrentUser, hasAnyUser } from "@/lib/auth";
import { safeNextPath } from "@/lib/links";

export const dynamic = "force-dynamic";

export default async function LoginPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const next = safeNextPath((await searchParams).next);
  if (await getCurrentUser()) redirect(next);
  if (!(await hasAnyUser())) redirect("/setup");
  return (
    <AuthShell title="Sign in" subtitle="Use the email and password your administrator gave you.">
      <LoginForm next={next} />
    </AuthShell>
  );
}
