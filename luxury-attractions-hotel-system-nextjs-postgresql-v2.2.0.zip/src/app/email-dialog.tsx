"use client";

import { FormEvent, useState } from "react";
import { Loader2, Mail, Paperclip, X } from "lucide-react";
import { buildProposalPdf, formatDay, money, ProposalDoc, proposalFileName } from "@/lib/proposal-pdf";

export default function EmailDialog({
  proposal,
  senderName,
  onClose,
  onResult,
}: {
  proposal: ProposalDoc;
  senderName: string;
  onClose: () => void;
  onResult: (type: "success" | "error", message: string) => void;
}) {
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [attach, setAttach] = useState(true);
  const label = proposal.kind === "trip" ? "trip itinerary" : "hotel proposal";
  const summary = [
    ...proposal.stays.map((stay) => `• ${stay.hotel} — ${stay.room}, ${formatDay(stay.checkIn)} to ${formatDay(stay.checkOut)} (${stay.nights} night${stay.nights === 1 ? "" : "s"})`),
    ...proposal.lines.map((line) => `• ${formatDay(line.date)}${line.time ? ` ${line.time}` : ""} — ${line.name}`),
  ].join("\n");
  const defaultMessage = `Dear ${proposal.clientName || "Sir / Madam"},\n\nThank you for your enquiry. Please find your ${label} ${proposal.reference} below${attach ? " and attached as a PDF" : ""}.\n\n${summary}\n\nTotal price: ${money(proposal.total, proposal.currency)}${proposal.includeTax ? " (tourism tax included)" : ""}\n\nWe would be delighted to confirm this for you — simply reply to this email.\n\nKind regards,\n${senderName}\nLuxury Attractions`;

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setSending(true);
    setError("");
    try {
      const pdfBase64 = attach ? buildProposalPdf(proposal) : "";
      const response = await fetch("/api/email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: form.get("to"),
          cc: form.get("cc"),
          subject: form.get("subject"),
          message: form.get("message"),
          pdfBase64,
          fileName: attach ? proposalFileName(proposal.reference, proposal.title) : "",
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Email failed.");
      onResult("success", result.message || "Email sent.");
      onClose();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Email failed.";
      setError(message);
      onResult("error", message);
    } finally {
      setSending(false);
    }
  };

  const input = "h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10";
  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-slate-950/50 p-4" role="dialog" aria-modal="true">
      <form onSubmit={submit} className="flex max-h-[92vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-100 px-6 py-4">
          <div>
            <h2 className="flex items-center gap-2 text-lg font-extrabold text-slate-950"><Mail size={18} className="text-teal-700" /> Email {label}</h2>
            <p className="mt-0.5 text-xs text-slate-500">{proposal.reference} · {proposal.title}</p>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100" aria-label="Close"><X size={18} /></button>
        </div>
        <div className="space-y-3 overflow-y-auto px-6 py-5">
          {error && <p className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm font-semibold text-rose-700">{error}</p>}
          <label className="block text-xs font-bold text-slate-600">To (comma-separated)<input name="to" required defaultValue={proposal.clientEmail} className={`${input} mt-1`} /></label>
          <label className="block text-xs font-bold text-slate-600">Cc<input name="cc" className={`${input} mt-1`} /></label>
          <label className="block text-xs font-bold text-slate-600">Subject<input name="subject" required defaultValue={`${proposal.reference} — ${proposal.title || "Your proposal"} | Luxury Attractions`} className={`${input} mt-1`} /></label>
          <label className="block text-xs font-bold text-slate-600">Message<textarea name="message" rows={12} defaultValue={defaultMessage} className="mt-1 w-full rounded-xl border border-slate-200 p-3 text-sm leading-6 outline-none focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10" /></label>
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <input type="checkbox" checked={attach} onChange={(event) => setAttach(event.target.checked)} className="h-4 w-4 accent-teal-700" />
            <Paperclip size={14} /> Attach PDF ({proposalFileName(proposal.reference, proposal.title)}) — selling price only
          </label>
        </div>
        <div className="flex justify-end gap-2 border-t border-slate-100 px-6 py-4">
          <button type="button" onClick={onClose} className="h-10 rounded-xl border border-slate-200 px-4 text-sm font-bold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button disabled={sending} className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#174e48] px-5 text-sm font-bold text-white hover:bg-[#103f3a] disabled:opacity-50">
            {sending ? <Loader2 size={16} className="animate-spin" /> : <Mail size={16} />} {sending ? "Sending…" : "Send email"}
          </button>
        </div>
      </form>
    </div>
  );
}
