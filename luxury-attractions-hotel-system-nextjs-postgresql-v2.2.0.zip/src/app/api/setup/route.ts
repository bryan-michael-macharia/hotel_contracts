import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { hasAnyUser, hashPassword, startSession } from "@/lib/auth";
import { businessRowCount, ImportReport, parseBackupFile, runImport, setSetting } from "@/lib/backup";
import { seedSampleCatalogue } from "@/lib/hotel-data";
import { PERMISSIONS, serialisePermissions } from "@/lib/permissions";
import { seedReferenceLists } from "@/lib/setup-data";

export const dynamic = "force-dynamic";

/** First-run setup (equivalent of the Laravel /install wizard). Only works while no user exists. */
export async function POST(request: Request) {
  try {
    if (await hasAnyUser()) return NextResponse.json({ error: "Setup has already been completed. Sign in instead." }, { status: 403 });

    const form = await request.formData();
    const name = String(form.get("name") ?? "").trim();
    const email = String(form.get("email") ?? "").trim().toLowerCase();
    const password = String(form.get("password") ?? "");
    const confirm = String(form.get("confirm") ?? "");
    const phone = String(form.get("phone") ?? "").trim();
    const start = String(form.get("start") ?? "sample");
    const file = form.get("file");

    if (!name || !email) return NextResponse.json({ error: "Enter the administrator name and email." }, { status: 400 });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
    if (password.length < 8) return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    if (password !== confirm) return NextResponse.json({ error: "The two passwords do not match." }, { status: 400 });

    const existingRows = await businessRowCount();
    let report: ImportReport | null = null;
    let message = "";

    if (existingRows > 0) {
      // Upgrade path: a database from an earlier version already holds data. Keep it exactly as it is.
      message = `Existing data kept (${existingRows} records). Nothing was imported or seeded.`;
    } else if (start === "import") {
      if (!(file instanceof File) || file.size === 0) return NextResponse.json({ error: "Choose the export file to import." }, { status: 400 });
      const parsed = parseBackupFile(await file.text());
      report = await runImport(parsed, { mode: "replace", dryRun: false, actor: null, snapshotNote: "Setup import" });
      const total = report.tables.reduce((sum, table) => sum + table.inserted, 0);
      message = `Imported ${total} records and ${report.users.created + report.users.updated} user account(s) from ${parsed.source}.`;
    } else if (start === "empty") {
      await seedReferenceLists();
      message = "Started with an empty catalogue (reference lists only).";
    } else {
      await seedSampleCatalogue();
      message = "Sample catalogue loaded.";
    }

    // Create the administrator, or promote/refresh the imported account that uses this email.
    const values = { name, passwordHash: hashPassword(password), role: "admin", permissions: serialisePermissions(PERMISSIONS), phone, active: true, mustChangePassword: false };
    const [existing] = await db.select({ id: users.id }).from(users).where(sql`lower(${users.email}) = ${email}`).limit(1);
    let adminId: number;
    if (existing) {
      await db.update(users).set(values).where(sql`${users.id} = ${existing.id}`);
      adminId = existing.id;
    } else {
      const [created] = await db.insert(users).values({ email, ...values }).returning({ id: users.id });
      adminId = created.id;
    }

    await setSetting("initialized_at", new Date().toISOString());
    await startSession(adminId);
    return NextResponse.json({ ok: true, message, report });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Setup failed." }, { status: 400 });
  }
}
