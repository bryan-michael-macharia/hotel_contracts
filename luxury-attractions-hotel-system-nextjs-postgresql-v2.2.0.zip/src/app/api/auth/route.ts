import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { endSession, getCurrentUser, hashPassword, startSession, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

// Simple in-memory throttle (same limit as the Laravel build: 20 attempts per minute per IP).
const attempts = new Map<string, { count: number; resetAt: number }>();
function throttled(ip: string) {
  const now = Date.now();
  const entry = attempts.get(ip);
  if (!entry || entry.resetAt < now) {
    attempts.set(ip, { count: 1, resetAt: now + 60_000 });
    return false;
  }
  entry.count++;
  return entry.count > 20;
}

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
    const action = String(body.action || "login");

    if (action === "logout") {
      await endSession();
      return NextResponse.json({ ok: true });
    }

    if (action === "change-password") {
      const current = await getCurrentUser();
      if (!current) return NextResponse.json({ error: "Please sign in first." }, { status: 401 });
      const currentPassword = String(body.currentPassword || "");
      const newPassword = String(body.newPassword || "");
      if (newPassword.length < 8) return NextResponse.json({ error: "New password must be at least 8 characters." }, { status: 400 });
      const [row] = await db.select().from(users).where(eq(users.id, current.id)).limit(1);
      if (!row || !verifyPassword(currentPassword, row.passwordHash)) {
        return NextResponse.json({ error: "Your current password is incorrect." }, { status: 400 });
      }
      await db.update(users).set({ passwordHash: hashPassword(newPassword), mustChangePassword: false }).where(eq(users.id, current.id));
      return NextResponse.json({ ok: true });
    }

    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
    if (throttled(ip)) return NextResponse.json({ error: "Too many sign-in attempts. Wait a minute and try again." }, { status: 429 });

    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!email || !password) return NextResponse.json({ error: "Enter your email and password." }, { status: 400 });
    const [row] = await db.select().from(users).where(sql`lower(${users.email}) = ${email}`).limit(1);
    if (!row || !row.active || !verifyPassword(password, row.passwordHash)) {
      return NextResponse.json({ error: "Incorrect email or password." }, { status: 401 });
    }
    await startSession(row.id);
    await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, row.id));
    return NextResponse.json({ ok: true, mustChangePassword: row.mustChangePassword });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Sign in failed. Please try again." }, { status: 500 });
  }
}
