import { NextResponse } from "next/server";
import { getCurrentUser, requirePermission } from "@/lib/auth";
import {
  createSnapshot,
  deleteSnapshot,
  exportAll,
  getSnapshotPayload,
  getTableCounts,
  ImportMode,
  listSnapshots,
  parseBackupFile,
  runImport,
} from "@/lib/backup";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

const stamp = (date: Date) => date.toISOString().slice(0, 16).replace("T", "-").replace(":", "");

function download(body: string, fileName: string) {
  return new NextResponse(body, {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Cache-Control": "no-store",
    },
  });
}

/** GET ?download=full → backup file · GET ?snapshot=ID → snapshot file · GET → snapshot list + counts. */
export async function GET(request: Request) {
  const denied = await requirePermission("settings");
  if (denied) return denied;
  try {
    const params = new URL(request.url).searchParams;
    if (params.get("download") === "full") {
      const user = await getCurrentUser();
      const backup = await exportAll(`Downloaded by ${user?.email ?? "unknown"}`);
      return download(JSON.stringify(backup, null, 1), `luxury-attractions-backup-${stamp(new Date())}.json`);
    }
    const snapshotId = Number(params.get("snapshot"));
    if (snapshotId) {
      const snapshot = await getSnapshotPayload(snapshotId);
      if (!snapshot) return NextResponse.json({ error: "Snapshot not found." }, { status: 404 });
      return download(snapshot.payload, `luxury-attractions-${snapshot.kind}-snapshot-${stamp(snapshot.createdAt)}.json`);
    }
    const [snapshots, counts] = await Promise.all([listSnapshots(), getTableCounts()]);
    return NextResponse.json({ snapshots, counts });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to read backups." }, { status: 500 });
  }
}

/**
 * multipart/form-data { file, mode: replace|merge, dryRun: "1"|"0" } → import (preview first)
 * JSON { action: "snapshot", note } → create a restore point
 * JSON { action: "restore", id, dryRun } → restore a snapshot (a new restore point is taken first)
 */
export async function POST(request: Request) {
  const denied = await requirePermission("settings");
  if (denied) return denied;
  const user = await getCurrentUser();
  try {
    const contentType = request.headers.get("content-type") ?? "";
    if (contentType.includes("multipart/form-data")) {
      const form = await request.formData();
      const file = form.get("file");
      if (!(file instanceof File) || file.size === 0) return NextResponse.json({ error: "Choose a file to import." }, { status: 400 });
      const mode: ImportMode = form.get("mode") === "merge" ? "merge" : "replace";
      const dryRun = form.get("dryRun") !== "0";
      const parsed = parseBackupFile(await file.text());
      const report = await runImport(parsed, { mode, dryRun, actor: user, snapshotNote: `Before importing ${file.name} (${mode})` });
      return NextResponse.json({ report });
    }

    const body = (await request.json()) as Record<string, unknown>;
    if (body.action === "snapshot") {
      const id = await createSnapshot("manual", String(body.note || "").trim() || "Manual restore point", user?.email ?? "");
      return NextResponse.json({ ok: true, id, message: "Restore point created." });
    }
    if (body.action === "restore") {
      const id = Number(body.id);
      const snapshot = id ? await getSnapshotPayload(id) : null;
      if (!snapshot) return NextResponse.json({ error: "Snapshot not found." }, { status: 404 });
      const parsed = parseBackupFile(snapshot.payload);
      parsed.source = `Restore point #${id} (${snapshot.createdAt.toISOString().slice(0, 16).replace("T", " ")} UTC)`;
      const report = await runImport(parsed, {
        mode: "replace",
        dryRun: body.dryRun !== false,
        actor: user,
        snapshotNote: `Before restoring restore point #${id}`,
      });
      return NextResponse.json({ report });
    }
    return NextResponse.json({ error: "Unknown action." }, { status: 400 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Import failed." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const denied = await requirePermission("settings");
  if (denied) return denied;
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Snapshot id is required." }, { status: 400 });
  await deleteSnapshot(id);
  return NextResponse.json({ ok: true });
}
