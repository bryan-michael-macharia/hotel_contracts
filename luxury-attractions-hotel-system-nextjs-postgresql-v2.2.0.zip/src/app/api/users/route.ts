import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser, hashPassword, requirePermission } from "@/lib/auth";
import { isRole, ROLE_PRESETS, serialisePermissions } from "@/lib/permissions";

export const dynamic = "force-dynamic";

async function adminCount() {
  const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(users).where(sql`${users.role} = 'admin' AND ${users.active} = true`);
  return row?.count ?? 0;
}

export async function POST(request: Request) {
  const denied = await requirePermission("users");
  if (denied) return denied;
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const email = String(body.email || "").trim().toLowerCase();
    const name = String(body.name || "").trim();
    const password = String(body.password || "");
    const role = String(body.role || "agent");
    if (!email || !name) return NextResponse.json({ error: "Name and email are required." }, { status: 400 });
    if (password.length < 8) return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    if (!isRole(role)) return NextResponse.json({ error: "Choose a valid role." }, { status: 400 });
    const [dupe] = await db.select({ id: users.id }).from(users).where(sql`lower(${users.email}) = ${email}`).limit(1);
    if (dupe) return NextResponse.json({ error: "A user with that email already exists." }, { status: 409 });
    const permissions = Array.isArray(body.permissions) && body.permissions.length > 0 ? body.permissions : ROLE_PRESETS[role].permissions;
    const [created] = await db
      .insert(users)
      .values({
        email,
        name,
        passwordHash: hashPassword(password),
        role,
        permissions: serialisePermissions(role === "admin" ? ROLE_PRESETS.admin.permissions : permissions),
        phone: String(body.phone || ""),
        active: true,
        mustChangePassword: body.mustChangePassword !== false,
      })
      .returning({ id: users.id, email: users.email, name: users.name, role: users.role });
    return NextResponse.json({ user: created }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to create this user." }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  const denied = await requirePermission("users");
  if (denied) return denied;
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!id) return NextResponse.json({ error: "User id is required." }, { status: 400 });
    const [target] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    if (!target) return NextResponse.json({ error: "User not found." }, { status: 404 });

    const patch: Partial<typeof users.$inferInsert> = {};
    if ("name" in body) patch.name = String(body.name ?? "").trim() || target.name;
    if ("phone" in body) patch.phone = String(body.phone ?? "");
    const nextRole = "role" in body && isRole(body.role) ? body.role : null;
    const losesAdmin = target.role === "admin" && ((nextRole && nextRole !== "admin") || ("active" in body && !body.active));
    if (losesAdmin && (await adminCount()) <= 1) {
      return NextResponse.json({ error: "You cannot disable or demote the last administrator." }, { status: 400 });
    }
    if (nextRole) patch.role = nextRole;
    if (Array.isArray(body.permissions)) patch.permissions = serialisePermissions((nextRole ?? target.role) === "admin" ? ROLE_PRESETS.admin.permissions : body.permissions);
    if ("active" in body) patch.active = Boolean(body.active);
    if (typeof body.password === "string" && body.password.length > 0) {
      if (body.password.length < 8) return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
      patch.passwordHash = hashPassword(body.password);
      patch.mustChangePassword = true;
    }
    const [updated] = await db.update(users).set(patch).where(eq(users.id, id)).returning({ id: users.id, name: users.name, role: users.role });
    return NextResponse.json({ user: updated });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to update this user." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const denied = await requirePermission("users");
  if (denied) return denied;
  try {
    const me = await getCurrentUser();
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return NextResponse.json({ error: "User id is required." }, { status: 400 });
    if (me && id === me.id) return NextResponse.json({ error: "You cannot delete your own account." }, { status: 400 });
    const [target] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    if (!target) return NextResponse.json({ error: "User not found." }, { status: 404 });
    if (target.role === "admin" && (await adminCount()) <= 1) {
      return NextResponse.json({ error: "You cannot delete the last administrator." }, { status: 400 });
    }
    await db.delete(users).where(eq(users.id, id));
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to delete this user." }, { status: 400 });
  }
}
