import { getCurrentUser, requirePermission } from "@/lib/auth";
import { createSnapshot } from "@/lib/backup";
import { db } from "@/db";
import { bookings, bookingItems, quotationItems, ratePeriods, roomTypes } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";

const isDate = (value: unknown) => /^\d{4}-\d{2}-\d{2}$/.test(String(value));
const amount = (value: unknown, fallback = 0) => String(Math.max(0, Number(value) || fallback));

function exclusions(value: unknown): string {
  const list = Array.isArray(value) ? value : typeof value === "string" ? value.split(",") : [];
  return Array.from(new Set(list.map((item) => String(item).trim().toLowerCase()).filter((item) => item !== "all" && /^[a-z0-9_]+$/.test(item)))).join(",");
}

function parseRate(body: Record<string, unknown>, hotelId: number, roomTypeId: number) {
  const validFrom = String(body.validFrom || "");
  const validTo = String(body.validTo || "");
  const name = String(body.name ?? "").trim();
  if (!hotelId || !roomTypeId || !name || !isDate(validFrom) || !isDate(validTo) || validTo < validFrom) {
    throw new Error("Hotel, room, rate name, and a valid date range are required.");
  }
  const bookingWindowStart = isDate(body.bookingWindowStart) ? String(body.bookingWindowStart) : null;
  const bookingWindowEnd = isDate(body.bookingWindowEnd) ? String(body.bookingWindowEnd) : null;
  if (bookingWindowStart && bookingWindowEnd && bookingWindowEnd < bookingWindowStart) {
    throw new Error("The booking window end must be after its start.");
  }
  const requestedMarket = String(body.market || "all");
  const market = requestedMarket === "all" || /^[a-z0-9_]+$/.test(requestedMarket) ? requestedMarket : "all";
  return {
    name,
    boardType: String(body.boardType || "breakfast"),
    validFrom,
    validTo,
    bookingWindowStart,
    bookingWindowEnd,
    market,
    marketExclusions: exclusions(body.marketExclusions),
    promoCode: String(body.promoCode || "").trim(),
    baseRate: amount(body.baseRate),
    rateBasis: String(body.rateBasis || "room_night"),
    boardAdultSupplement: amount(body.boardAdultSupplement),
    boardChildSupplement: amount(body.boardChildSupplement),
    boardSupplementBasis: String(body.boardSupplementBasis || "person_night"),
    extraAdultRate: amount(body.extraAdultRate),
    extraChildRate: amount(body.extraChildRate),
    extraBedRate: amount(body.extraBedRate),
    extraBedBasis: String(body.extraBedBasis || "bed_night"),
    minimumNights: Math.max(1, Math.floor(Number(body.minimumNights) || 1)),
    ...(body.active === undefined ? {} : { active: Boolean(body.active) }),
  };
}

export async function POST(request: Request) {
  const denied = await requirePermission("rates");
  if (denied) return denied;
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const hotelId = Number(body.hotelId);
    const roomTypeId = Number(body.roomTypeId);
    const values = parseRate(body, hotelId, roomTypeId);
    const [room] = await db.select({ id: roomTypes.id }).from(roomTypes).where(eq(roomTypes.id, roomTypeId)).limit(1);
    if (!room) return Response.json({ error: "Choose a room type that still exists." }, { status: 400 });
    const [rate] = await db.insert(ratePeriods).values({ hotelId, roomTypeId, ...values }).returning();
    revalidatePath("/");
    return Response.json({ rate }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error && /required|valid date|booking window/.test(error.message) ? error.message : "Unable to save this rate plan.";
    return Response.json({ error: message }, { status: 400 });
  }
}

/** Update all editable price, board, season, promo, booking-window and market fields in place. */
export async function PATCH(request: Request) {
  const denied = await requirePermission("rates");
  if (denied) return denied;
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Rate plan id is required." }, { status: 400 });
    const [current] = await db.select().from(ratePeriods).where(eq(ratePeriods.id, id)).limit(1);
    if (!current) return Response.json({ error: "Rate plan not found." }, { status: 404 });
    const values = parseRate({
      name: body.name ?? current.name,
      boardType: body.boardType ?? current.boardType,
      validFrom: body.validFrom ?? current.validFrom,
      validTo: body.validTo ?? current.validTo,
      bookingWindowStart: body.bookingWindowStart === undefined ? current.bookingWindowStart : body.bookingWindowStart,
      bookingWindowEnd: body.bookingWindowEnd === undefined ? current.bookingWindowEnd : body.bookingWindowEnd,
      market: body.market ?? current.market,
      marketExclusions: body.marketExclusions ?? current.marketExclusions,
      promoCode: body.promoCode ?? current.promoCode,
      baseRate: body.baseRate ?? current.baseRate,
      rateBasis: body.rateBasis ?? current.rateBasis,
      boardAdultSupplement: body.boardAdultSupplement ?? current.boardAdultSupplement,
      boardChildSupplement: body.boardChildSupplement ?? current.boardChildSupplement,
      boardSupplementBasis: body.boardSupplementBasis ?? current.boardSupplementBasis,
      extraAdultRate: body.extraAdultRate ?? current.extraAdultRate,
      extraChildRate: body.extraChildRate ?? current.extraChildRate,
      extraBedRate: body.extraBedRate ?? current.extraBedRate,
      extraBedBasis: body.extraBedBasis ?? current.extraBedBasis,
      minimumNights: body.minimumNights ?? current.minimumNights,
      active: body.active ?? current.active,
    }, current.hotelId, current.roomTypeId);
    const [rate] = await db.update(ratePeriods).set(values).where(eq(ratePeriods.id, id)).returning();
    revalidatePath("/");
    return Response.json({ rate });
  } catch (error) {
    const message = error instanceof Error && /required|valid date|booking window/.test(error.message) ? error.message : "Unable to update this rate plan.";
    return Response.json({ error: message }, { status: 400 });
  }
}

/** Delete an unused rate; booking and quotation rate snapshots are preserved. */
export async function DELETE(request: Request) {
  const denied = await requirePermission("rates");
  if (denied) return denied;
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Rate plan id is required." }, { status: 400 });
  try {
    const result = await db.transaction(async (tx) => {
      const [rate] = await tx.select().from(ratePeriods).where(eq(ratePeriods.id, id)).limit(1);
      if (!rate) return { missing: true as const };
      const [bookingCount, bookingItemCount, quotationItemCount] = await Promise.all([
        tx.select({ count: sql<number>`count(*)::int` }).from(bookings).where(eq(bookings.ratePeriodId, id)),
        tx.select({ count: sql<number>`count(*)::int` }).from(bookingItems).where(eq(bookingItems.ratePeriodId, id)),
        tx.select({ count: sql<number>`count(*)::int` }).from(quotationItems).where(eq(quotationItems.ratePeriodId, id)),
      ]);
      const references = (bookingCount[0]?.count ?? 0) + (bookingItemCount[0]?.count ?? 0) + (quotationItemCount[0]?.count ?? 0);
      if (references) return { blocked: true as const, references };
      const actor = await getCurrentUser();
      await createSnapshot("pre-delete", `Before deleting rate plan #${id} (${rate.name})`, actor?.email ?? "system");
      await tx.delete(ratePeriods).where(eq(ratePeriods.id, id));
      return { deleted: true as const };
    });
    if ("missing" in result) return Response.json({ error: "Rate plan not found." }, { status: 404 });
    if ("blocked" in result) return Response.json({ error: `This rate is referenced by ${result.references} saved booking/quotation record(s). It cannot be deleted; deactivate it to preserve history.`, references: result.references }, { status: 409 });
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch (error) {
    console.error("Rate plan deletion failed", error);
    return Response.json({ error: "Unable to delete this rate. Existing linked records were preserved." }, { status: 409 });
  }
}
