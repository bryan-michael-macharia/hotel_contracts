import { getCurrentUser, requirePermission } from "@/lib/auth";
import { createSnapshot } from "@/lib/backup";
import { db } from "@/db";
import { bookings, bookingItems, occupancyRules, quotationItems, roomBedding, roomTypes } from "@/db/schema";
import { BEDDING_KINDS } from "@/lib/search-engine";
import { eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";

const BEDDING_INPUT: Record<string, { max: string; free: string; rate: string }> = {
  extra_bed: { max: "extraBedMax", free: "extraBedFree", rate: "extraBedRate" },
  sofa_bed: { max: "sofaBedMax", free: "sofaBedFree", rate: "sofaBedRate" },
  baby_cot: { max: "babyCotMax", free: "babyCotFree", rate: "babyCotRate" },
};

function occupancyFromBody(body: Record<string, unknown>, roomTypeId: number) {
  const raw = Array.isArray(body.occupancies) ? body.occupancies : [];
  const parsed = raw
    .map((value) => {
      const item = value && typeof value === "object" ? (value as Record<string, unknown>) : {};
      const adults = Math.max(0, Math.floor(Number(item.adults) || 0));
      const children = Math.max(0, Math.floor(Number(item.children) || 0));
      const infants = Math.max(0, Math.floor(Number(item.infants) || 0));
      const extraBeds = Math.max(0, Math.floor(Number(item.extraBeds) || 0));
      const label = String(item.label ?? "").trim();
      return {
        roomTypeId,
        adults,
        children,
        infants,
        extraBeds,
        label: label || `${adults}A${children ? ` + ${children}C` : ""}${infants ? ` + ${infants}I` : ""}${extraBeds ? ` + ${extraBeds} extra bed` : ""}`,
      };
    })
    .filter((item) => item.adults > 0);
  return parsed;
}

function defaultOccupancy(roomTypeId: number, maxAdults: number, maxChildren: number) {
  const rules: (typeof occupancyRules.$inferInsert)[] = [
    { roomTypeId, adults: 1, children: 0, infants: 0, extraBeds: 0, label: "Single use" },
    { roomTypeId, adults: Math.min(2, maxAdults), children: 0, infants: 0, extraBeds: 0, label: "Double" },
  ];
  if (maxChildren > 0) rules.push({ roomTypeId, adults: 1, children: Math.min(2, maxChildren), infants: 0, extraBeds: 0, label: "1 adult + 2 children" });
  if (maxAdults > 2) rules.push({ roomTypeId, adults: maxAdults, children: 0, infants: 0, extraBeds: 0, label: `${maxAdults} adults` });
  return rules;
}

function beddingFromBody(body: Record<string, unknown>, roomTypeId: number) {
  return BEDDING_KINDS.flatMap((kind) => {
    const fields = BEDDING_INPUT[kind.value];
    const maxPerRoom = Math.max(0, Number(body[fields.max]) || 0);
    if (maxPerRoom === 0) return [];
    return [
      {
        roomTypeId,
        kind: kind.value,
        label: String(body[`${kind.value}Label`] || kind.label),
        maxPerRoom,
        free: Boolean(body[fields.free]),
        ratePerNight: String(Math.max(0, Number(body[fields.rate]) || 0)),
        perStay: Boolean(body[`${kind.value}PerStay`]),
        sortOrder: (BEDDING_KINDS.findIndex((item) => item.value === kind.value) + 1) * 10,
      },
    ];
  });
}

export async function POST(request: Request) {
  const denied = await requirePermission("rooms");
  if (denied) return denied;
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const duplicateFrom = Number(body.duplicateFrom);
    if (duplicateFrom > 0) {
      const [source] = await db.select().from(roomTypes).where(eq(roomTypes.id, duplicateFrom)).limit(1);
      if (!source) return Response.json({ error: "Room type to duplicate was not found." }, { status: 404 });
      const existing = await db.select({ code: roomTypes.code }).from(roomTypes).where(eq(roomTypes.hotelId, source.hotelId));
      const codes = new Set(existing.map((item) => item.code));
      let suffix = 2;
      let nextCode = `${source.code}-${suffix}`;
      while (codes.has(nextCode) && suffix < 99) {
        suffix += 1;
        nextCode = `${source.code}-${suffix}`;
      }
      const [room] = await db
        .insert(roomTypes)
        .values({
          hotelId: source.hotelId,
          name: `${source.name} (copy)`,
          code: nextCode,
          category: source.category,
          description: source.description,
          maxAdults: source.maxAdults,
          maxChildren: source.maxChildren,
          maxInfants: source.maxInfants,
          includedAdults: source.includedAdults,
          baseSleeps: source.baseSleeps,
          defaultInventory: source.defaultInventory,
          extraBedAllowed: source.extraBedAllowed,
          mediaLink: source.mediaLink,
        })
        .returning();
      const occupancy = await db.select().from(occupancyRules).where(eq(occupancyRules.roomTypeId, source.id));
      if (occupancy.length) {
        await db.insert(occupancyRules).values(occupancy.map((rule) => ({ roomTypeId: room.id, adults: rule.adults, children: rule.children, infants: rule.infants, extraBeds: rule.extraBeds, label: rule.label })));
      }
      const bedding = await db.select().from(roomBedding).where(eq(roomBedding.roomTypeId, source.id));
      if (bedding.length) {
        await db.insert(roomBedding).values(bedding.map((item) => ({ roomTypeId: room.id, kind: item.kind, label: item.label, maxPerRoom: item.maxPerRoom, free: item.free, ratePerNight: item.ratePerNight, perStay: item.perStay, sortOrder: item.sortOrder })));
      }
      revalidatePath("/");
      return Response.json({ room }, { status: 201 });
    }

    const hotelId = Number(body.hotelId);
    const name = String(body.name ?? "").trim();
    const code = String(body.code ?? "").trim().toUpperCase();
    const category = String(body.category || "").trim();
    if (!hotelId || !name || !code || !category) {
      return Response.json({ error: "Hotel, room name, code and category are required." }, { status: 400 });
    }

    const maxAdults = Math.max(1, Number(body.maxAdults) || 2);
    const maxChildren = Math.max(0, Number(body.maxChildren) || 0);
    const maxInfants = Math.max(0, Number(body.maxInfants) || 0);
    const baseSleeps = Math.max(1, Number(body.baseSleeps) || 2);

    const [room] = await db
      .insert(roomTypes)
      .values({
        hotelId,
        name,
        code,
        category,
        description: String(body.description || ""),
        maxAdults,
        maxChildren,
        maxInfants,
        includedAdults: Math.max(1, Number(body.includedAdults) || 2),
        baseSleeps,
        defaultInventory: Math.max(1, Number(body.defaultInventory) || 1),
        extraBedAllowed: Number(body.extraBedMax) > 0,
        mediaLink: String(body.mediaLink || ""),
      })
      .returning();

    const beddingValues = beddingFromBody(body, room.id);
    if (beddingValues.length > 0) await db.insert(roomBedding).values(beddingValues);

    const occupancy = occupancyFromBody(body, room.id);
    await db.insert(occupancyRules).values(occupancy.length ? occupancy : defaultOccupancy(room.id, maxAdults, maxChildren));

    revalidatePath("/");
    return Response.json({ room }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error && error.message.includes("unique")
      ? "That room code already exists for this hotel."
      : "Unable to save this room type.";
    return Response.json({ error: message }, { status: 400 });
  }
}

export async function PATCH(request: Request) {
  const denied = await requirePermission("rooms");
  if (denied) return denied;
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = Number(body.id);
    if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Room type id is required." }, { status: 400 });
    const [room] = await db.select().from(roomTypes).where(eq(roomTypes.id, id)).limit(1);
    if (!room) return Response.json({ error: "Room type not found." }, { status: 404 });

    const patch: Partial<typeof roomTypes.$inferInsert> = {};
    if (body.defaultInventory !== undefined) patch.defaultInventory = Math.max(0, Math.floor(Number(body.defaultInventory) || 0));
    if (body.mediaLink !== undefined) patch.mediaLink = String(body.mediaLink || "");
    if (body.maxAdults !== undefined) patch.maxAdults = Math.max(1, Math.floor(Number(body.maxAdults) || 1));
    if (body.maxChildren !== undefined) patch.maxChildren = Math.max(0, Math.floor(Number(body.maxChildren) || 0));
    if (body.maxInfants !== undefined) patch.maxInfants = Math.max(0, Math.floor(Number(body.maxInfants) || 0));
    if (body.baseSleeps !== undefined) patch.baseSleeps = Math.max(1, Math.floor(Number(body.baseSleeps) || 1));
    if (body.includedAdults !== undefined) patch.includedAdults = Math.max(1, Math.floor(Number(body.includedAdults) || 1));
    if (body.name !== undefined) patch.name = String(body.name).trim() || room.name;
    if (body.code !== undefined) patch.code = String(body.code).trim().toUpperCase() || room.code;
    if (body.category !== undefined) patch.category = String(body.category).trim() || room.category;
    if (body.description !== undefined) patch.description = String(body.description || "");
    if (body.active !== undefined) patch.active = Boolean(body.active);
    if (body.maxAdults !== undefined || body.maxChildren !== undefined || body.maxInfants !== undefined) {
      patch.extraBedAllowed = body.extraBedAllowed === undefined ? room.extraBedAllowed : Boolean(body.extraBedAllowed);
    }
    if (Object.keys(patch).length === 0 && !Array.isArray(body.occupancies) && !Array.isArray(body.bedding)) {
      return Response.json({ error: "Nothing to update." }, { status: 400 });
    }

    const updated = await db.transaction(async (tx) => {
      let saved = room;
      if (Object.keys(patch).length) {
        const [row] = await tx.update(roomTypes).set(patch).where(eq(roomTypes.id, id)).returning();
        saved = row;
      }
      if (Array.isArray(body.occupancies)) {
        await tx.delete(occupancyRules).where(eq(occupancyRules.roomTypeId, id));
        const combinations = occupancyFromBody(body, id);
        await tx.insert(occupancyRules).values(combinations.length ? combinations : defaultOccupancy(id, patch.maxAdults ?? room.maxAdults, patch.maxChildren ?? room.maxChildren));
      }
      if (Array.isArray(body.bedding)) {
        const items = body.bedding.flatMap((value) => {
          const item = value && typeof value === "object" ? value as Record<string, unknown> : {};
          const kind = BEDDING_KINDS.find((entry) => entry.value === String(item.kind || ""))?.value;
          const maxPerRoom = Math.max(0, Math.min(4, Math.floor(Number(item.maxPerRoom) || 0)));
          if (!kind || maxPerRoom === 0) return [];
          return [{
            roomTypeId: id,
            kind,
            label: String(item.label || BEDDING_KINDS.find((entry) => entry.value === kind)?.label || kind),
            maxPerRoom,
            free: Boolean(item.free),
            ratePerNight: String(Math.max(0, Number(item.ratePerNight) || 0)),
            perStay: Boolean(item.perStay),
            sortOrder: (BEDDING_KINDS.findIndex((entry) => entry.value === kind) + 1) * 10,
          }];
        });
        await tx.delete(roomBedding).where(eq(roomBedding.roomTypeId, id));
        if (items.length) await tx.insert(roomBedding).values(items);
      }
      return saved;
    });
    revalidatePath("/");
    return Response.json({ room: updated });
  } catch (error) {
    const message = error instanceof Error && error.message.includes("unique")
      ? "That room code already exists for this hotel."
      : "Unable to update this room type.";
    return Response.json({ error: message }, { status: 400 });
  }
}

/** Remove a room only when no booking or quotation uses it; child contract details cascade. */
export async function DELETE(request: Request) {
  const denied = await requirePermission("rooms");
  if (denied) return denied;
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isSafeInteger(id) || id < 1) return Response.json({ error: "Room type id is required." }, { status: 400 });
  try {
    const result = await db.transaction(async (tx) => {
      const [room] = await tx.select().from(roomTypes).where(eq(roomTypes.id, id)).limit(1);
      if (!room) return { missing: true as const };
      const [bookingCount, bookingItemCount, quotationItemCount] = await Promise.all([
        tx.select({ count: sql<number>`count(*)::int` }).from(bookings).where(eq(bookings.roomTypeId, id)),
        tx.select({ count: sql<number>`count(*)::int` }).from(bookingItems).where(eq(bookingItems.roomTypeId, id)),
        tx.select({ count: sql<number>`count(*)::int` }).from(quotationItems).where(eq(quotationItems.roomTypeId, id)),
      ]);
      const references = (bookingCount[0]?.count ?? 0) + (bookingItemCount[0]?.count ?? 0) + (quotationItemCount[0]?.count ?? 0);
      if (references) return { blocked: true as const, references };
      const actor = await getCurrentUser();
      await createSnapshot("pre-delete", `Before deleting room type #${id} (${room.name})`, actor?.email ?? "system");
      await tx.delete(roomTypes).where(eq(roomTypes.id, id));
      return { deleted: true as const };
    });
    if ("missing" in result) return Response.json({ error: "Room type not found." }, { status: 404 });
    if ("blocked" in result) return Response.json({ error: `This room type is used by ${result.references} saved booking/quotation record(s). It cannot be deleted; set its inventory to 0 or deactivate it to preserve history.`, references: result.references }, { status: 409 });
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch (error) {
    console.error("Room type deletion failed", error);
    return Response.json({ error: "Unable to delete this room type. Existing linked records were preserved." }, { status: 409 });
  }
}
