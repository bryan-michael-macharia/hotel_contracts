import { requirePermission } from "@/lib/auth";
import { db } from "@/db";
import { locations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  const denied = await requirePermission("hotels");
  if (denied) return denied;
  try {
    const body = await request.json();
    const city = String(body.city ?? "").trim();
    const name = String(body.name ?? "").trim();
    if (!city || !name) {
      return Response.json({ error: "Choose the city/emirate and enter the location name." }, { status: 400 });
    }
    const [location] = await db
      .insert(locations)
      .values({ city: city.slice(0, 120), name: name.slice(0, 120) })
      .onConflictDoUpdate({ target: [locations.city, locations.name], set: { active: true } })
      .returning();
    revalidatePath("/");
    return Response.json({ location }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this location." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  const denied = await requirePermission("hotels");
  if (denied) return denied;
  try {
    const id = Number(new URL(request.url).searchParams.get("id"));
    if (!id) return Response.json({ error: "Location id is required." }, { status: 400 });
    await db.delete(locations).where(eq(locations.id, id));
    revalidatePath("/");
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Unable to delete this location." }, { status: 400 });
  }
}
