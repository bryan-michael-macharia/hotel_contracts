import { NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import nodemailer from "nodemailer";
import { db } from "@/db";
import { smtpSettings } from "@/db/schema";
import { getCurrentUser, requirePermission } from "@/lib/auth";

export const dynamic = "force-dynamic";

async function smtpRow() {
  const [row] = await db.select().from(smtpSettings).orderBy(asc(smtpSettings.id)).limit(1);
  return row ?? null;
}

const escapeHtml = (value: string) => value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const splitList = (value: string) => value.split(/[,;]/).map((item) => item.trim()).filter(Boolean);

/** Save SMTP settings (permission: settings). An empty password keeps the stored one. */
export async function PUT(request: Request) {
  const denied = await requirePermission("settings");
  if (denied) return denied;
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const existing = await smtpRow();
    const values = {
      host: String(body.host || "").trim(),
      port: Math.max(1, Number(body.port) || 587),
      secure: Boolean(body.secure),
      username: String(body.username || "").trim(),
      password: String(body.password || "") || existing?.password || "",
      fromName: String(body.fromName || "Luxury Attractions").trim(),
      fromEmail: String(body.fromEmail || "").trim(),
      replyTo: String(body.replyTo || "").trim(),
      bccSelf: Boolean(body.bccSelf),
      active: Boolean(body.active),
      updatedAt: new Date(),
    };
    if (!values.host || !values.fromEmail) return NextResponse.json({ error: "SMTP host and the from-address are required." }, { status: 400 });
    const [saved] = existing
      ? await db.update(smtpSettings).set(values).where(eq(smtpSettings.id, existing.id)).returning()
      : await db.insert(smtpSettings).values(values).returning();
    return NextResponse.json({ settings: { ...saved, password: saved.password ? "********" : "" } });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to save SMTP settings." }, { status: 400 });
  }
}

/** Send a proposal (permission: send_email) or a test message ({ action: "test" }). */
export async function POST(request: Request) {
  const denied = await requirePermission("send_email");
  if (denied) return denied;
  try {
    const user = await getCurrentUser();
    const body = (await request.json()) as Record<string, unknown>;
    const settings = await smtpRow();
    if (!settings || !settings.active || !settings.host) {
      return NextResponse.json({ error: "Email is not configured yet. Add SMTP details in Users & settings first." }, { status: 400 });
    }
    const transport = nodemailer.createTransport({
      host: settings.host,
      port: settings.port,
      secure: settings.secure,
      auth: settings.username ? { user: settings.username, pass: settings.password } : undefined,
    });
    const from = { name: settings.fromName || "Luxury Attractions", address: settings.fromEmail };

    if (body.action === "test") {
      const to = String(body.to || user?.email || settings.fromEmail);
      await transport.sendMail({
        from,
        to,
        subject: "Luxury Attractions — SMTP test",
        text: "Your SMTP settings are working. Quotations and trip packages can now be emailed from the system.",
      });
      return NextResponse.json({ ok: true, message: `Test email sent to ${to}.` });
    }

    const to = String(body.to || "").trim();
    const subject = String(body.subject || "").trim();
    const message = String(body.message || "").trim();
    if (!to || !subject) return NextResponse.json({ error: "Recipient and subject are required." }, { status: 400 });
    const paragraphs = message
      .split("\n")
      .map((line) => `<p style="margin:0 0 10px">${line === "" ? "&nbsp;" : escapeHtml(line)}</p>`)
      .join("");
    const html = `<div style="font-family:Segoe UI,Helvetica,Arial,sans-serif;font-size:14px;color:#1e293b;line-height:1.6">${paragraphs}<hr style="border:none;border-top:1px solid #e2e8f0;margin:18px 0" /><p style="margin:0;font-size:12px;color:#64748b"><b style="color:#174e48">Luxury Attractions</b><br/>hotels.luxuryattractions.com</p></div>`;
    const pdfBase64 = String(body.pdfBase64 || "").replace(/^data:application\/pdf;base64,/, "");
    const fileName = String(body.fileName || "").trim();
    const cc = String(body.cc || "").trim();

    await transport.sendMail({
      from,
      to: splitList(to),
      cc: cc ? splitList(cc) : undefined,
      bcc: settings.bccSelf ? settings.fromEmail : undefined,
      replyTo: settings.replyTo || undefined,
      subject,
      text: message,
      html,
      attachments: pdfBase64 && fileName ? [{ filename: fileName, content: Buffer.from(pdfBase64, "base64"), contentType: "application/pdf" }] : undefined,
    });
    return NextResponse.json({ ok: true, message: `Email sent to ${to}.` });
  } catch (error) {
    return NextResponse.json({ error: `Email failed: ${error instanceof Error ? error.message : String(error)}` }, { status: 502 });
  }
}
