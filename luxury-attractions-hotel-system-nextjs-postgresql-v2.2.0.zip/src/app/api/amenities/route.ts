import { requirePermission } from "@/lib/auth";
import { db } from "@/db";
import { amenities } from "@/db/schema";
import { revalidatePath } from "next/cache";

const ICONS = ["waves", "umbrella", "dumbbell", "train", "check"];

function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40);
}

export async function POST(request: Request) {
  const denied = await requirePermission("hotels");
  if (denied) return denied;
  try {
    const body = await request.json();
    const label = String(body.label ?? "").trim();
    if (!label) return Response.json({ error: "Give the amenity a name, e.g. Spa." }, { status: 400 });
    const slug = String(body.slug || slugify(label));
    if (!slug) return Response.json({ error: "Could not build a code for that amenity name." }, { status: 400 });

    const icon = ICONS.includes(String(body.icon)) ? String(body.icon) : "check";
    const [amenity] = await db
      .insert(amenities)
      .values({ slug, label, icon, sortOrder: Math.max(0, Number(body.sortOrder) || 100) })
      .onConflictDoUpdate({ target: amenities.slug, set: { label, icon } })
      .returning();
    revalidatePath("/");
    return Response.json({ amenity }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to save this amenity." }, { status: 400 });
  }
}
