import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hotel Contracts | Luxury Attractions",
  description: "B2B hotel contracts, rates, availability, and booking management for Luxury Attractions.",
  applicationName: "Luxury Attractions Hotel Contracts",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "48x48" },
      { url: "/icon.svg", type: "image/svg+xml" },
    ],
    apple: "/apple-touch-icon.png",
  },
  // Internal system: never index the sign-in or setup pages.
  robots: { index: false, follow: false },
};

export const viewport: Viewport = { themeColor: "#174e48" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
