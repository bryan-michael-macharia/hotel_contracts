"use client";

import { FormEvent, ReactNode, useState } from "react";
import { AlertTriangle, BedDouble, Building2, CalendarDays, Loader2, Save, X } from "lucide-react";
import type { BeddingRow, DashboardData, HotelRow, OccupancyRow, RateRow, RoomRow } from "./dashboard-client";
import { BEDDING_KINDS } from "@/lib/search-engine";
import { parseMarketList } from "@/lib/search-engine";

const fieldClass = "h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-800 outline-none transition focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10";
const selectClass = `${fieldClass} cursor-pointer`;
const primaryClass = "inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-[#174e48] px-4 text-sm font-bold text-white shadow-sm transition hover:bg-[#103f3a] disabled:opacity-50";
const secondaryClass = "inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-600 hover:bg-slate-50";

type OccupancyDraft = { adults: number; children: number; infants: number; extraBeds: number; label: string };

type EditorProps<T> = { record: T; data: DashboardData; onClose: () => void; onComplete: (message: string) => void };

function Frame({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-[85] flex items-center justify-center bg-slate-950/50 p-4" role="dialog" aria-modal="true" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className="flex max-h-[94vh] w-full max-w-4xl flex-col overflow-hidden rounded-[22px] bg-white shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-4">
          <div><h2 className="text-lg font-extrabold text-slate-950">{title}</h2><p className="mt-1 text-xs text-slate-500">{subtitle}</p></div>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100"><X size={18} /></button>
        </div>
        <div className="overflow-y-auto px-5 py-5 sm:px-6">{children}</div>
      </div>
    </div>
  );
}

function Field({ label, children, className = "", hint }: { label: string; children: ReactNode; className?: string; hint?: string }) {
  return <label className={`block ${className}`}><span className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.05em] text-slate-500">{label}</span>{children}{hint && <span className="mt-1 block text-[10px] text-slate-400">{hint}</span>}</label>;
}

function ErrorMessage({ children }: { children: string }) {
  return children ? <p role="alert" className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-700"><AlertTriangle size={15} className="mt-0.5 shrink-0" />{children}</p> : null;
}

async function saveRecord(url: string, body: Record<string, unknown>) {
  const response = await fetch(url, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Unable to save changes.");
  return result;
}

export function HotelEditor({ record: hotel, data, onClose, onComplete }: EditorProps<HotelRow>) {
  const [city, setCity] = useState(hotel.city);
  const [locationId, setLocationId] = useState(hotel.locationId ? String(hotel.locationId) : "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const matchingLocations = data.locations.filter((location) => location.city.toLowerCase() === city.trim().toLowerCase());

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setSaving(true);
    setError("");
    try {
      await saveRecord("/api/hotels", {
        id: hotel.id,
        name: String(form.get("name") || "").trim(),
        supplierCode: String(form.get("supplierCode") || "").trim(),
        city: String(form.get("city") || "").trim(),
        country: String(form.get("country") || "").trim(),
        locationId: Number(locationId) || null,
        address: String(form.get("address") || "").trim(),
        starRating: Number(form.get("starRating")) || 5,
        groupId: Number(form.get("groupId")) || null,
        businessType: String(form.get("businessType") || "Hotel").trim(),
        website: String(form.get("website") || "").trim(),
        contractsFolderLink: String(form.get("contractsFolderLink") || "").trim(),
        mediaLink: String(form.get("mediaLink") || "").trim(),
        contactEmail: String(form.get("contactEmail") || "").trim(),
        contactPhone: String(form.get("contactPhone") || "").trim(),
        currency: String(form.get("currency") || "AED").trim(),
        checkInTime: String(form.get("checkInTime") || "15:00"),
        checkOutTime: String(form.get("checkOutTime") || "12:00"),
        tourismTax: Number(form.get("tourismTax")) || 0,
        tourismTaxBasis: String(form.get("tourismTaxBasis") || "room_night"),
        active: form.get("active") === "on",
        amenityIds: form.getAll("amenityIds").map(Number),
      });
      onComplete(`${String(form.get("name") || hotel.name)} updated. Existing rooms, rates, contacts and bookings were kept.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to update this hotel.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Frame title="Edit hotel" subtitle={`Hotel #${hotel.id} · ${hotel.supplierCode} · contacts and existing room/rate records are kept.`} onClose={onClose}>
      <form onSubmit={submit} className="grid gap-4 md:grid-cols-2">
        <ErrorMessage>{error}</ErrorMessage>
        <div className="md:col-span-2 grid gap-4 sm:grid-cols-2">
          <Field label="Hotel name"><input name="name" required defaultValue={hotel.name} className={fieldClass} /></Field>
          <Field label="Supplier code" hint="Must be unique."><input name="supplierCode" required defaultValue={hotel.supplierCode} className={fieldClass} /></Field>
          <Field label="City / emirate"><input name="city" required value={city} onChange={(event) => { setCity(event.target.value); if (!data.locations.some((item) => item.id === Number(locationId) && item.city.toLowerCase() === event.target.value.trim().toLowerCase())) setLocationId(""); }} list={`edit-hotel-cities-${hotel.id}`} className={fieldClass} /><datalist id={`edit-hotel-cities-${hotel.id}`}>{Array.from(new Set([...data.hotels.map((item) => item.city), ...data.locations.map((item) => item.city)])).sort().map((item) => <option key={item} value={item} />)}</datalist></Field>
          <Field label="Location / district"><select value={locationId} onChange={(event) => setLocationId(event.target.value)} className={selectClass}><option value="">No location</option>{matchingLocations.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></Field>
          <Field label="Country"><input name="country" defaultValue={hotel.country} className={fieldClass} /></Field>
          <Field label="Address"><input name="address" defaultValue={hotel.address} className={fieldClass} /></Field>
          <Field label="Star rating"><select name="starRating" defaultValue={hotel.starRating} className={selectClass}>{[5, 4, 3, 2, 1].map((stars) => <option key={stars} value={stars}>{stars} stars</option>)}</select></Field>
          <Field label="Hotel group"><select name="groupId" defaultValue={hotel.groupId ?? ""} className={selectClass}><option value="">Independent / no group</option>{data.hotelGroups.map((group) => <option key={group.id} value={group.id}>{group.name}</option>)}</select></Field>
          <Field label="Business type"><input name="businessType" defaultValue={hotel.businessType} className={fieldClass} /></Field>
          <Field label="Website"><input name="website" type="url" defaultValue={hotel.website} className={fieldClass} /></Field>
          <Field label="Contracts folder link"><input name="contractsFolderLink" type="url" defaultValue={hotel.contractsFolderLink} className={fieldClass} /></Field>
          <Field label="Media link"><input name="mediaLink" type="url" defaultValue={hotel.mediaLink} className={fieldClass} /></Field>
          <Field label="Hotel contact email"><input name="contactEmail" type="email" defaultValue={hotel.contactEmail} className={fieldClass} /></Field>
          <Field label="Hotel contact phone"><input name="contactPhone" defaultValue={hotel.contactPhone} className={fieldClass} /></Field>
          <Field label="Check-in time"><input name="checkInTime" type="time" defaultValue={hotel.checkInTime} className={fieldClass} /></Field>
          <Field label="Check-out time"><input name="checkOutTime" type="time" defaultValue={hotel.checkOutTime} className={fieldClass} /></Field>
          <Field label="Tourism tax (AED)"><input name="tourismTax" type="number" min="0" step="0.01" defaultValue={hotel.tourismTax} className={fieldClass} /></Field>
          <Field label="Tourism tax charged"><select name="tourismTaxBasis" defaultValue={hotel.tourismTaxBasis} className={selectClass}><option value="room_night">Per room / night</option><option value="person_night">Per person / night</option><option value="per_stay">Per room / stay</option></select></Field>
          <Field label="Currency"><input name="currency" defaultValue={hotel.currency || "AED"} className={fieldClass} /></Field>
        </div>
        <fieldset className="md:col-span-2 rounded-xl border border-slate-200 p-3">
          <legend className="px-1 text-[11px] font-bold uppercase tracking-wider text-slate-500">Hotel amenities</legend>
          <div className="grid gap-2 sm:grid-cols-3">
            {data.amenities.map((amenity) => <label key={amenity.id} className="flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700"><input type="checkbox" name="amenityIds" value={amenity.id} defaultChecked={data.hotelAmenities.some((item) => item.hotelId === hotel.id && item.amenityId === amenity.id)} className="accent-teal-700" />{amenity.label}</label>)}
            {data.amenities.length === 0 && <span className="text-xs text-slate-400">No amenity types yet.</span>}
          </div>
        </fieldset>
        <label className="md:col-span-2 flex items-center gap-2 text-xs font-semibold text-slate-700"><input name="active" type="checkbox" defaultChecked={hotel.active} className="h-4 w-4 accent-teal-700" /> Hotel active and available in search</label>
        <div className="md:col-span-2 flex flex-wrap justify-end gap-2 border-t border-slate-100 pt-4">
          <button type="button" onClick={onClose} className={secondaryClass}>Cancel</button>
          <button disabled={saving} className={primaryClass}>{saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />} Save hotel</button>
        </div>
      </form>
    </Frame>
  );
}

export function RoomEditor({ record: room, data, onClose, onComplete }: EditorProps<RoomRow>) {
  const existingOccupancies = data.occupancies.filter((item) => item.roomTypeId === room.id);
  const [occupancies, setOccupancies] = useState<OccupancyDraft[]>(() => existingOccupancies.map(({ adults, children, infants, extraBeds, label }) => ({ adults, children, infants, extraBeds, label })));
  const existingBedding = data.bedding.filter((item) => item.roomTypeId === room.id);
  const beddingFor = (kind: string) => existingBedding.find((item) => item.kind === kind);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const patchOccupancy = (index: number, patch: Partial<OccupancyDraft>) => setOccupancies((items) => items.map((item, i) => i === index ? { ...item, ...patch } : item));
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setSaving(true);
    setError("");
    const bedding = BEDDING_KINDS.flatMap((kind) => {
      const maxPerRoom = Math.max(0, Number(form.get(`${kind.value}Max`)) || 0);
      if (maxPerRoom === 0) return [];
      const old = beddingFor(kind.value);
      return [{ kind: kind.value, label: old?.label || kind.label, maxPerRoom, free: form.get(`${kind.value}Free`) === "on", ratePerNight: Number(form.get(`${kind.value}Rate`)) || 0, perStay: form.get(`${kind.value}PerStay`) === "on" }];
    });
    try {
      await saveRecord("/api/rooms", {
        id: room.id,
        name: String(form.get("name") || "").trim(),
        code: String(form.get("code") || "").trim(),
        category: String(form.get("category") || room.category),
        description: String(form.get("description") || ""),
        maxAdults: Number(form.get("maxAdults")),
        maxChildren: Number(form.get("maxChildren")),
        maxInfants: Number(form.get("maxInfants")),
        includedAdults: Number(form.get("includedAdults")),
        baseSleeps: Number(form.get("baseSleeps")),
        defaultInventory: Number(form.get("defaultInventory")),
        mediaLink: String(form.get("mediaLink") || "").trim(),
        active: form.get("active") === "on",
        occupancies: occupancies.filter((item) => item.adults > 0),
        bedding,
      });
      onComplete(`${String(form.get("name") || room.name)} updated. Existing rates and reservation records were kept.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to update this room type.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Frame title="Edit room type" subtitle={`${data.hotels.find((hotel) => hotel.id === room.hotelId)?.name ?? "Hotel"} · ${room.code} · changing inventory does not change existing bookings.`} onClose={onClose}>
      <form onSubmit={submit} className="grid gap-4 md:grid-cols-2">
        <div className="md:col-span-2 flex items-center gap-2 rounded-xl bg-teal-50 px-3 py-2 text-xs font-semibold text-teal-800"><BedDouble size={15} /> Hotel assignment is fixed to protect linked quotations and bookings.</div>
        <div className="md:col-span-2"><ErrorMessage>{error}</ErrorMessage></div>
        <Field label="Room name"><input name="name" required defaultValue={room.name} className={fieldClass} /></Field>
        <Field label="Room code"><input name="code" required defaultValue={room.code} className={fieldClass} /></Field>
        <Field label="Search category"><select name="category" defaultValue={room.category} className={selectClass}>{data.roomCategories.map((item) => <option key={item.slug} value={item.slug}>{item.label}</option>)}</select></Field>
        <Field label="Contracted allocation (rooms)" hint="This is the inventory available to search and availability checks."><input name="defaultInventory" type="number" min="0" step="1" required defaultValue={room.defaultInventory} className={fieldClass} /></Field>
        <Field label="Maximum adults"><input name="maxAdults" type="number" min="1" defaultValue={room.maxAdults} className={fieldClass} /></Field>
        <Field label="Adults included in base rate"><input name="includedAdults" type="number" min="1" defaultValue={room.includedAdults} className={fieldClass} /></Field>
        <Field label="Maximum children"><input name="maxChildren" type="number" min="0" defaultValue={room.maxChildren} className={fieldClass} /></Field>
        <Field label="Maximum infants"><input name="maxInfants" type="number" min="0" defaultValue={room.maxInfants} className={fieldClass} /></Field>
        <Field label="Sleeps without extra bedding"><input name="baseSleeps" type="number" min="1" defaultValue={room.baseSleeps} className={fieldClass} /></Field>
        <Field label="Room media link"><input name="mediaLink" type="url" defaultValue={room.mediaLink} className={fieldClass} /></Field>
        <Field label="Description" className="md:col-span-2"><textarea name="description" rows={2} defaultValue={room.description} className="w-full rounded-xl border border-slate-200 p-3 text-sm outline-none focus:border-teal-600 focus:ring-4 focus:ring-teal-700/10" /></Field>
        <label className="md:col-span-2 flex items-center gap-2 text-xs font-semibold text-slate-700"><input name="active" type="checkbox" defaultChecked={room.active} className="h-4 w-4 accent-teal-700" /> Room active and available in search</label>

        <section className="md:col-span-2 rounded-xl border border-slate-200 p-3">
          <div className="mb-3 flex items-center justify-between"><h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500">Permitted occupancy combinations</h3><button type="button" onClick={() => setOccupancies((items) => [...items, { adults: 2, children: 0, infants: 0, extraBeds: 0, label: "" }])} className="text-xs font-bold text-teal-700">+ Add combination</button></div>
          {occupancies.map((item, index) => <div key={index} className="mb-2 grid gap-2 rounded-lg bg-slate-50 p-2 sm:grid-cols-[70px_70px_70px_70px_minmax(100px,1fr)_32px]">
            <Field label="Adults"><input type="number" min="0" value={item.adults} onChange={(event) => patchOccupancy(index, { adults: Number(event.target.value) })} className={fieldClass} /></Field>
            <Field label="Children"><input type="number" min="0" value={item.children} onChange={(event) => patchOccupancy(index, { children: Number(event.target.value) })} className={fieldClass} /></Field>
            <Field label="Infants"><input type="number" min="0" value={item.infants} onChange={(event) => patchOccupancy(index, { infants: Number(event.target.value) })} className={fieldClass} /></Field>
            <Field label="Extra beds"><input type="number" min="0" value={item.extraBeds} onChange={(event) => patchOccupancy(index, { extraBeds: Number(event.target.value) })} className={fieldClass} /></Field>
            <Field label="Description"><input value={item.label} onChange={(event) => patchOccupancy(index, { label: event.target.value })} className={fieldClass} /></Field>
            <button type="button" onClick={() => setOccupancies((items) => items.filter((_, i) => i !== index))} className="self-end rounded-lg p-2 text-rose-600 hover:bg-rose-50" aria-label="Remove occupancy"><X size={15} /></button>
          </div>)}
          {occupancies.length === 0 && <p className="text-xs text-slate-400">No custom combinations. Saving uses standard occupancy rules.</p>}
        </section>

        <section className="md:col-span-2 rounded-xl border border-slate-200 p-3">
          <h3 className="mb-3 text-xs font-extrabold uppercase tracking-wider text-slate-500">Extra bedding</h3>
          <div className="grid gap-3 md:grid-cols-3">
            {BEDDING_KINDS.map((kind) => {
              const bed = beddingFor(kind.value);
              return <div key={kind.value} className="rounded-lg bg-slate-50 p-3">
                <div className="mb-2 text-xs font-extrabold text-slate-800">{kind.label}</div>
                <Field label="Max per room"><input name={`${kind.value}Max`} type="number" min="0" max="4" defaultValue={bed?.maxPerRoom ?? 0} className={fieldClass} /></Field>
                <Field label="Price per night (AED)" className="mt-2"><input name={`${kind.value}Rate`} type="number" min="0" step="0.01" defaultValue={bed?.ratePerNight ?? 0} className={fieldClass} /></Field>
                <label className="mt-2 flex items-center gap-2 text-xs text-slate-600"><input name={`${kind.value}Free`} type="checkbox" defaultChecked={bed?.free ?? false} className="accent-teal-700" /> Free</label>
                <label className="mt-1 flex items-center gap-2 text-xs text-slate-600"><input name={`${kind.value}PerStay`} type="checkbox" defaultChecked={bed?.perStay ?? false} className="accent-teal-700" /> Charge per stay</label>
              </div>;
            })}
          </div>
        </section>
        <div className="md:col-span-2 flex justify-end gap-2 border-t border-slate-100 pt-4"><button type="button" onClick={onClose} className={secondaryClass}>Cancel</button><button disabled={saving} className={primaryClass}>{saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />} Save room type</button></div>
      </form>
    </Frame>
  );
}

export function RateEditor({ record: rate, data, onClose, onComplete }: EditorProps<RateRow>) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const excluded = new Set(parseMarketList(rate.marketExclusions));
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setSaving(true);
    setError("");
    try {
      await saveRecord("/api/rates", {
        id: rate.id,
        name: String(form.get("name") || "").trim(),
        boardType: String(form.get("boardType") || "breakfast"),
        validFrom: String(form.get("validFrom") || ""),
        validTo: String(form.get("validTo") || ""),
        bookingWindowStart: String(form.get("bookingWindowStart") || "") || null,
        bookingWindowEnd: String(form.get("bookingWindowEnd") || "") || null,
        market: String(form.get("market") || "all"),
        marketExclusions: form.getAll("marketExclusions").map(String),
        promoCode: String(form.get("promoCode") || "").trim(),
        baseRate: Number(form.get("baseRate")) || 0,
        rateBasis: String(form.get("rateBasis") || "room_night"),
        boardAdultSupplement: Number(form.get("boardAdultSupplement")) || 0,
        boardChildSupplement: Number(form.get("boardChildSupplement")) || 0,
        boardSupplementBasis: String(form.get("boardSupplementBasis") || "person_night"),
        extraAdultRate: Number(form.get("extraAdultRate")) || 0,
        extraChildRate: Number(form.get("extraChildRate")) || 0,
        extraBedRate: Number(form.get("extraBedRate")) || 0,
        extraBedBasis: String(form.get("extraBedBasis") || "bed_night"),
        minimumNights: Number(form.get("minimumNights")) || 1,
        active: form.get("active") === "on",
      });
      onComplete(`${String(form.get("name") || rate.name)} updated.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to update this rate plan.");
    } finally {
      setSaving(false);
    }
  };
  const hotel = data.hotels.find((item) => item.id === rate.hotelId);
  const room = data.rooms.find((item) => item.id === rate.roomTypeId);
  return (
    <Frame title="Edit rate & board plan" subtitle={`Rate #${rate.id} · ${hotel?.name ?? "Hotel"} / ${room?.name ?? "Room"}. Hotel and room assignments stay unchanged.`} onClose={onClose}>
      <form onSubmit={submit} className="grid gap-4 md:grid-cols-2">
        <div className="md:col-span-2"><ErrorMessage>{error}</ErrorMessage></div>
        <div className="md:col-span-2 grid gap-3 sm:grid-cols-2"><div className="rounded-xl bg-slate-50 p-3"><span className="text-[10px] font-bold uppercase text-slate-400">Hotel</span><div className="mt-1 text-sm font-bold text-slate-800">{hotel?.name ?? "Unknown hotel"}</div></div><div className="rounded-xl bg-slate-50 p-3"><span className="text-[10px] font-bold uppercase text-slate-400">Room type</span><div className="mt-1 text-sm font-bold text-slate-800">{room?.name ?? "Unknown room"}</div></div></div>
        <Field label="Rate name"><input name="name" required defaultValue={rate.name} className={fieldClass} /></Field>
        <Field label="Board type"><select name="boardType" defaultValue={rate.boardType} className={selectClass}><option value="room_only">Room only</option><option value="breakfast">Bed & breakfast</option><option value="half_board">Half board</option><option value="full_board">Full board</option></select></Field>
        <Field label="Stay period from"><input name="validFrom" required type="date" defaultValue={rate.validFrom.slice(0, 10)} className={fieldClass} /></Field>
        <Field label="Stay period to"><input name="validTo" required type="date" defaultValue={rate.validTo.slice(0, 10)} className={fieldClass} /></Field>
        <Field label="Booking opens (optional)"><input name="bookingWindowStart" type="date" defaultValue={rate.bookingWindowStart?.slice(0, 10) ?? ""} className={fieldClass} /></Field>
        <Field label="Booking closes (optional)"><input name="bookingWindowEnd" type="date" defaultValue={rate.bookingWindowEnd?.slice(0, 10) ?? ""} className={fieldClass} /></Field>
        <Field label="Market"><select name="market" defaultValue={rate.market} className={selectClass}>{data.markets.map((item) => <option key={item.slug} value={item.slug}>{item.label}</option>)}</select></Field>
        <Field label="Promo code"><input name="promoCode" defaultValue={rate.promoCode} className={fieldClass} /></Field>
        <fieldset className="md:col-span-2 rounded-xl border border-slate-200 p-3"><legend className="px-1 text-[11px] font-bold uppercase text-slate-500">Markets not applicable</legend><div className="flex flex-wrap gap-2">{data.markets.filter((item) => item.slug !== "all").map((item) => <label key={item.slug} className="flex items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-2 text-xs font-semibold text-slate-700"><input type="checkbox" name="marketExclusions" value={item.slug} defaultChecked={excluded.has(item.slug)} className="accent-teal-700" />{item.label}</label>)}</div></fieldset>
        <Field label="Base rate (AED)"><input name="baseRate" type="number" min="0" step="0.01" required defaultValue={rate.baseRate} className={fieldClass} /></Field>
        <Field label="Rate basis"><select name="rateBasis" defaultValue={rate.rateBasis} className={selectClass}><option value="room_night">Per room / night</option><option value="person_night">Per person / night</option></select></Field>
        <Field label="Meal supplement — adult"><input name="boardAdultSupplement" type="number" min="0" step="0.01" defaultValue={rate.boardAdultSupplement} className={fieldClass} /></Field>
        <Field label="Meal supplement — child"><input name="boardChildSupplement" type="number" min="0" step="0.01" defaultValue={rate.boardChildSupplement} className={fieldClass} /></Field>
        <Field label="Meal supplement charged"><select name="boardSupplementBasis" defaultValue={rate.boardSupplementBasis} className={selectClass}><option value="person_night">Per person / night</option><option value="room_night">Per room / night</option></select></Field>
        <Field label="Extra adult / night"><input name="extraAdultRate" type="number" min="0" step="0.01" defaultValue={rate.extraAdultRate} className={fieldClass} /></Field>
        <Field label="Extra child / night"><input name="extraChildRate" type="number" min="0" step="0.01" defaultValue={rate.extraChildRate} className={fieldClass} /></Field>
        <Field label="Extra bed rate"><input name="extraBedRate" type="number" min="0" step="0.01" defaultValue={rate.extraBedRate} className={fieldClass} /></Field>
        <Field label="Extra bed basis"><select name="extraBedBasis" defaultValue={rate.extraBedBasis} className={selectClass}><option value="bed_night">Per bed / night</option><option value="per_stay">Per bed / stay</option></select></Field>
        <Field label="Minimum nights"><input name="minimumNights" type="number" min="1" step="1" defaultValue={rate.minimumNights} className={fieldClass} /></Field>
        <label className="md:col-span-2 flex items-center gap-2 text-xs font-semibold text-slate-700"><input name="active" type="checkbox" defaultChecked={rate.active} className="h-4 w-4 accent-teal-700" /> Rate active and available for search</label>
        <div className="md:col-span-2 flex justify-end gap-2 border-t border-slate-100 pt-4"><button type="button" onClick={onClose} className={secondaryClass}>Cancel</button><button disabled={saving} className={primaryClass}>{saving ? <Loader2 size={15} className="animate-spin" /> : <CalendarDays size={15} />} Save rate plan</button></div>
      </form>
    </Frame>
  );
}

export function recordDeleteWarning(kind: "hotel" | "room" | "rate", historyCount: number) {
  const noun = kind === "hotel" ? "hotel" : kind === "room" ? "room type" : "rate plan";
  const history = historyCount > 0 ? ` ${historyCount} booking/quotation record(s) refer to it, so deletion will be blocked to keep sales history.` : " No booking or quotation history refers to it.";
  const children = kind === "hotel" ? " Its rooms, rates, stop-sale dates, amenity links and hotel-only contact assignments will also be removed." : kind === "room" ? " Its seasonal rates, stop-sale dates, occupancy rules and extra-bedding settings will also be removed." : " Historical booking/quotation line items will be kept; the API will block deletion if they reference this rate.";
  return `Permanently delete this ${noun}?${children}${history} This cannot be undone. Download a backup first.`;
}
