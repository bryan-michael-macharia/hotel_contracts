import type { ReactNode } from "react";
import { Hotel, ShieldCheck } from "lucide-react";

export default function AuthShell({ title, subtitle, children, wide }: { title: string; subtitle: string; children: ReactNode; wide?: boolean }) {
  return (
    <div className="grid min-h-screen bg-[#f5f7f9] lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
      <aside className="relative hidden overflow-hidden bg-[#173f3b] p-12 text-white lg:flex lg:flex-col">
        <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-teal-400/10" />
        <div className="absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-[#b27a4b]/15" />
        <div className="relative flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-white/10"><Hotel size={22} /></div>
          <div>
            <div className="text-lg font-extrabold tracking-tight">Luxury Attractions</div>
            <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#e2b48b]">Hotel contracts</div>
          </div>
        </div>
        <div className="relative mt-auto max-w-md">
          <h2 className="text-3xl font-extrabold leading-tight tracking-tight">Negotiated rates, quotations, trip packages and bookings — in one place.</h2>
          <p className="mt-4 text-sm leading-6 text-teal-50/75">Search every contracted hotel, build multi-stay proposals with your markup, email PDFs to clients and confirm bookings.</p>
          <div className="mt-8 flex items-center gap-2 rounded-xl bg-white/5 p-3 text-xs text-teal-50/85"><ShieldCheck size={16} className="shrink-0 text-emerald-300" /> Daily restore points and safety copies before every import keep your data safe.</div>
        </div>
      </aside>
      <main className="flex items-center justify-center p-5 sm:p-10">
        <div className={`w-full ${wide ? "max-w-2xl" : "max-w-md"}`}>
          <div className="mb-6 flex items-center gap-3 lg:hidden">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-[#164e48] text-white"><Hotel size={20} /></div>
            <div className="text-base font-extrabold">Luxury Attractions</div>
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-950 md:text-3xl">{title}</h1>
          <p className="mt-1.5 text-sm text-slate-500">{subtitle}</p>
          <div className="mt-7">{children}</div>
        </div>
      </main>
    </div>
  );
}
