# Luxury Attractions — Hotel Contracts (Next.js + PostgreSQL) · v2.2.0

Same screens and features as `luxury-attractions-hotel-system-laravel-mysql-v2.0.0`:
Search & compare, Quotations, Trip Packages, Overview, Bookings, Hotels, Room types, Rates & board,
Blackout dates, **Users & settings** (roles & permissions, SMTP), PDF proposals and **email to client** —
plus a new **Data & backups** module so you can keep changing the system without losing data.

## Update zip for the Laravel 2.0.0 subdomain

For the Laravel/MySQL site already running at `hotels.luxuryattractions.com`, use the **overlay update zip**:

[Download Laravel v2.0.0 CRUD update](/downloads/luxury-attractions-hotel-system-laravel-v2.0.0-crud-update.zip)

It adds hotel/room/rate editing and safe deletion to the existing compiled Laravel screen. It contains only
`ApiController.php`, a small additive controller trait, route/view changes, and two UI assets—**no `.env`,
`vendor`, installer, migration or database data**. Back up the database first, then extract at the folder
containing `artisan`, replacing only the included files. Do not delete the old project files or re-run `/install`.
The zip includes `INSTALL-UPDATE.txt` with the exact cPanel steps and rollback instructions.

The Next.js + PostgreSQL source in this workspace is a separate build. It includes the same CRUD features but
is not a PHP/MySQL deployment package. [Download the complete Next.js v2.2.0 source](/downloads/luxury-attractions-hotel-system-nextjs-postgresql-v2.2.0.zip).

## First run
Open the site → **/setup** (shown only while no user exists):
1. Create the administrator.
2. Choose **Sample catalogue**, **Start empty**, or **Import my existing data**.
   If the database already contains data (e.g. an earlier version), it is detected and kept exactly as is.

## Links
Put your address in front, e.g. `https://hotels.luxuryattractions.com/?view=quotations`.

| Page | Link |
|---|---|
| Dashboard (Search & compare) | `/` |
| First-run setup (only until an administrator exists) | `/setup` |
| Sign in | `/login` (after sign-in it opens the screen you asked for, via `?next=`) |
| Health check | `/api/health` |
| Full backup download (admin, signed in) | `/api/backup?download=full` |

Every screen has its own link. Bookmark or share it: signed-out users sign in first and then land on that
screen; a screen the user has no permission for opens Search instead.

| Screen | Link |
|---|---|
| Search & compare | `/?view=search` |
| Quotations | `/?view=quotations` |
| Trip Packages | `/?view=trips` |
| Overview | `/?view=dashboard` (or `/?view=overview`) |
| Bookings | `/?view=bookings` |
| Hotels | `/?view=hotels` |
| Room types | `/?view=rooms` |
| Rates & board | `/?view=rates` |
| Blackout dates | `/?view=blackouts` |
| Users & settings | `/?view=admin` · tabs `&tab=users`, `&tab=backups`, `&tab=email` |

Sample-catalogue hotels have no Drive folders, so their Contracts / Media / Business card buttons are hidden
until you add real links. Imported data keeps your own links.

## Moving your data from the Laravel / MySQL system
Your MySQL database is only read — nothing there is changed.

| Way | How | Includes |
|---|---|---|
| phpMyAdmin (complete) | cPanel → phpMyAdmin → hotels DB → Export → Quick → **SQL** | Everything incl. staff passwords (bcrypt keeps working) and SMTP |
| Live system (easiest) | Sign in to the Laravel site, open `/api/bootstrap`, save as `.json` | All business data; staff passwords must be set again |
| Backup file | A `.json` downloaded from **Users & settings → Data & backups** | Everything |

Upload the file at setup, or later under **Users & settings → Data & backups → Import data**.
You always get a **preview** (current vs. file, per table) before anything is written.

## How your data is protected
- **No automatic reseeding.** The original app re-inserted demo hotels/quotations/services whenever a
  table was empty (on page load *and* on every search). That is removed; sample data is only inserted once,
  when chosen at setup.
- **Daily restore point** created automatically (last 14 kept) + manual restore points (last 40 kept).
- **Safety copy before every import, restore, or permanent hotel/room/rate deletion**; imports/restores run all-or-nothing.
- **Replace** (file becomes the new contents) or **Merge** (only adds records whose id is free; never changes rows).
- Staff accounts are matched by email and never deleted by an import; the signed-in admin is never modified.
- The backup `.json` uses the Laravel `demo.json` layout (snake_case tables/columns), so it works in both systems.

## Safe workflow for future changes
1. Users & settings → Data & backups → **Download backup** (and/or *Create restore point*).
2. Make code changes. Keep schema changes **additive** (new tables, new columns with defaults). Never drop or
   rename columns that hold data without a migration step.
3. Apply the schema: `npx drizzle-kit push` — if it ever warns about data loss, stop and review.
4. If anything looks wrong: **Restore points → Restore** (preview first) or import the downloaded backup.

## Development
```bash
npm install
cp .env.example .env         # DATABASE_URL=postgresql://user:pass@host:5432/db
npx drizzle-kit push         # creates/updates tables (additive)
npm run dev
```

## New API routes
| Route | Methods | Permission |
|---|---|---|
| `/api/setup` | POST | only while no user exists |
| `/api/auth` | POST (login, logout, change-password) | public / signed-in |
| `/api/users` | POST, PATCH, DELETE | `users` |
| `/api/email` | PUT (SMTP settings) · POST (send / test) | `settings` · `send_email` |
| `/api/backup` | GET (download, snapshots) · POST (import, snapshot, restore) · DELETE | `settings` |

All existing routes now require a signed-in user with the same permission as in the Laravel build
(e.g. `/api/rates` → `rates`, `/api/quotations` → `quotations`).
