<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        if (env('APP_FORCE_HTTPS', false)) \Illuminate\Support\Facades\URL::forceScheme('https');
    }
}
