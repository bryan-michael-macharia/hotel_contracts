<?php

namespace App\Http\Controllers;

use App\Support\Auth;
use App\Support\Rows;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Additive CRUD endpoints for live hotel contracts. Does not alter the existing schema. */
trait ContractCrud
{
    public function hotelsPatch(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $id = (int) self::n($b['id'] ?? null);
            $current = $id > 0 ? Rows::find('hotels', $id) : null;
            if (! $current) return self::json(['error' => 'Hotel not found.'], 404);
            $name = trim(self::s($b['name'] ?? $current['name']));
            $city = trim(self::s($b['city'] ?? $current['city']));
            $supplierCode = strtoupper(trim(self::s($b['supplierCode'] ?? $current['supplierCode'])));
            if (! $name || ! $city || ! $supplierCode) return self::json(['error' => 'Hotel name, city, and supplier code are required.'], 400);
            $groupId = array_key_exists('groupId', $b) ? (self::truthy($b['groupId']) ? (int) self::n($b['groupId']) : null) : $current['groupId'];
            $locationId = array_key_exists('locationId', $b) ? (self::truthy($b['locationId']) ? (int) self::n($b['locationId']) : null) : $current['locationId'];
            $amenityIds = array_key_exists('amenityIds', $b) ? self::parseIds($b['amenityIds']) : null;
            if (array_key_exists('amenityIds', $b) && $amenityIds === null) return self::json(['error' => 'Invalid amenity selection.'], 400);

            DB::transaction(function () use ($b, $id, $current, $name, $city, $supplierCode, $groupId, $locationId, $amenityIds) {
                if (DB::table('hotels')->whereRaw('LOWER(supplier_code) = ?', [strtolower($supplierCode)])->where('id', '<>', $id)->exists()) throw new \RuntimeException('That supplier code is already in use.');
                if ($groupId !== null && ! DB::table('hotel_groups')->where('id', $groupId)->exists()) throw new \RuntimeException('The selected umbrella company no longer exists.');
                if ($locationId !== null) {
                    $location = DB::table('locations')->where('id', $locationId)->first();
                    if (! $location) throw new \RuntimeException('The selected location no longer exists.');
                    if (strtolower((string) $location->city) !== strtolower($city)) throw new \RuntimeException('That location belongs to a different city/emirate.');
                }
                if ($amenityIds !== null && count($amenityIds) && DB::table('amenities')->whereIn('id', $amenityIds)->count() !== count($amenityIds)) throw new \RuntimeException('One or more selected amenities are no longer available.');
                Rows::update('hotels', $id, [
                    'name' => $name, 'city' => $city,
                    'country' => trim(self::s($b['country'] ?? $current['country'])), 'locationId' => $locationId,
                    'address' => self::s($b['address'] ?? $current['address']),
                    'starRating' => max(1, min(5, (int) (self::n($b['starRating'] ?? $current['starRating']) ?: 5))),
                    'supplierCode' => $supplierCode, 'groupId' => $groupId,
                    'businessType' => self::s($b['businessType'] ?? $current['businessType']),
                    'website' => self::s($b['website'] ?? $current['website']),
                    'contractsFolderLink' => self::s($b['contractsFolderLink'] ?? $current['contractsFolderLink']),
                    'mediaLink' => self::s($b['mediaLink'] ?? $current['mediaLink']),
                    'contactEmail' => self::s($b['contactEmail'] ?? $current['contactEmail']),
                    'contactPhone' => self::s($b['contactPhone'] ?? $current['contactPhone']),
                    'currency' => self::s($b['currency'] ?? $current['currency']),
                    'checkInTime' => self::s($b['checkInTime'] ?? $current['checkInTime']),
                    'checkOutTime' => self::s($b['checkOutTime'] ?? $current['checkOutTime']),
                    'tourismTax' => max(0, self::n($b['tourismTax'] ?? $current['tourismTax'])),
                    'tourismTaxBasis' => self::s($b['tourismTaxBasis'] ?? $current['tourismTaxBasis']),
                    'active' => array_key_exists('active', $b) ? self::truthy($b['active']) : $current['active'],
                ]);
                if ($amenityIds !== null) {
                    DB::table('hotel_amenities')->where('hotel_id', $id)->delete();
                    foreach ($amenityIds as $amenityId) Rows::insert('hotel_amenities', ['hotelId' => $id, 'amenityId' => $amenityId]);
                }
            });
            return self::json(['hotel' => Rows::find('hotels', $id)]);
        } catch (\Throwable $e) {
            report($e);
            $message = Rows::isUnique($e) ? 'That supplier code is already in use.' : $e->getMessage();
            if ($message === '' || str_contains($message, 'SQLSTATE')) $message = 'Unable to update this hotel.';
            return self::json(['error' => $message], 409);
        }
    }

    /** Historical references block deletion. Unused child contract records cascade normally. */
    public function hotelsDelete(Request $r)
    {
        [, $err] = Auth::guard('hotels');
        if ($err) return $err;
        $id = (int) self::n($r->query('id'));
        if ($id < 1) return self::json(['error' => 'Hotel id is required.'], 400);
        try {
            $result = DB::transaction(function () use ($id) {
                if (! DB::table('hotels')->where('id', $id)->exists()) return ['missing' => true];
                $refs = [
                    'bookings' => DB::table('bookings')->where('hotel_id', $id)->count(),
                    'bookingItems' => DB::table('booking_items')->where('hotel_id', $id)->count(),
                    'quotationItems' => DB::table('quotation_items')->where('hotel_id', $id)->count(),
                ];
                if (array_sum($refs) > 0) return ['references' => $refs];
                DB::table('hotels')->where('id', $id)->delete();
                return ['deleted' => true];
            });
            if (! empty($result['missing'])) return self::json(['error' => 'Hotel not found.'], 404);
            if (isset($result['references'])) return self::json(['error' => 'This hotel is linked to saved bookings or quotations. It cannot be deleted; disable it instead to preserve sales history.', 'references' => $result['references']], 409);
            return self::json(['ok' => true]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to delete this hotel. Existing linked records were preserved.'], 409);
        }
    }

    public function roomsUpdate(Request $r)
    {
        [, $err] = Auth::guard('rooms');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $id = (int) self::n($b['id'] ?? null);
            $room = $id > 0 ? Rows::find('room_types', $id) : null;
            if (! $room) return self::json(['error' => 'Room type not found.'], 404);
            $name = trim(self::s($b['name'] ?? $room['name']));
            $code = strtoupper(trim(self::s($b['code'] ?? $room['code'])));
            if (! $name || ! $code) return self::json(['error' => 'Room name and code are required.'], 400);
            if (DB::table('room_types')->where('hotel_id', $room['hotelId'])->whereRaw('LOWER(code) = ?', [strtolower($code)])->where('id', '<>', $id)->exists()) return self::json(['error' => 'That room code already exists for this hotel.'], 409);
            if (array_key_exists('occupancies', $b) && ! is_array($b['occupancies'])) return self::json(['error' => 'Invalid occupancy combinations.'], 400);
            if (array_key_exists('bedding', $b) && ! is_array($b['bedding'])) return self::json(['error' => 'Invalid extra bedding settings.'], 400);
            $maxAdults = max(1, (int) (self::n($b['maxAdults'] ?? $room['maxAdults']) ?: 1));
            $maxChildren = max(0, (int) self::n($b['maxChildren'] ?? $room['maxChildren']));
            $maxInfants = max(0, (int) self::n($b['maxInfants'] ?? $room['maxInfants']));
            DB::transaction(function () use ($b, $id, $room, $name, $code, $maxAdults, $maxChildren, $maxInfants) {
                Rows::update('room_types', $id, [
                    'name' => $name, 'code' => $code,
                    'category' => trim(self::s($b['category'] ?? $room['category'])) ?: $room['category'],
                    'description' => self::s($b['description'] ?? $room['description']),
                    'maxAdults' => $maxAdults, 'maxChildren' => $maxChildren, 'maxInfants' => $maxInfants,
                    'includedAdults' => max(1, (int) (self::n($b['includedAdults'] ?? $room['includedAdults']) ?: 1)),
                    'baseSleeps' => max(1, (int) (self::n($b['baseSleeps'] ?? $room['baseSleeps']) ?: 1)),
                    'defaultInventory' => max(0, (int) floor(self::n($b['defaultInventory'] ?? $room['defaultInventory']))),
                    'extraBedAllowed' => array_key_exists('extraBedAllowed', $b) ? self::truthy($b['extraBedAllowed']) : $room['extraBedAllowed'],
                    'mediaLink' => self::s($b['mediaLink'] ?? $room['mediaLink']),
                    'active' => array_key_exists('active', $b) ? self::truthy($b['active']) : $room['active'],
                ]);
                if (array_key_exists('occupancies', $b)) {
                    DB::table('occupancy_rules')->where('room_type_id', $id)->delete();
                    $rows = [];
                    foreach ($b['occupancies'] as $item) {
                        $item = is_array($item) ? $item : [];
                        $adults = max(0, (int) floor(self::n($item['adults'] ?? null)));
                        if ($adults < 1) continue;
                        $children = max(0, (int) floor(self::n($item['children'] ?? null)));
                        $infants = max(0, (int) floor(self::n($item['infants'] ?? null)));
                        $beds = max(0, (int) floor(self::n($item['extraBeds'] ?? null)));
                        $label = trim(self::s($item['label'] ?? null));
                        $rows[] = ['roomTypeId' => $id, 'adults' => $adults, 'children' => $children, 'infants' => $infants, 'extraBeds' => $beds, 'label' => $label ?: $adults.'A'.($children ? " + {$children}C" : '').($infants ? " + {$infants}I" : '').($beds ? " + {$beds} extra bed" : '')];
                    }
                    if (! $rows) {
                        $rows = [
                            ['roomTypeId' => $id, 'adults' => 1, 'children' => 0, 'infants' => 0, 'extraBeds' => 0, 'label' => 'Single use'],
                            ['roomTypeId' => $id, 'adults' => min(2, $maxAdults), 'children' => 0, 'infants' => 0, 'extraBeds' => 0, 'label' => 'Double'],
                        ];
                        if ($maxChildren > 0) $rows[] = ['roomTypeId' => $id, 'adults' => 1, 'children' => min(2, $maxChildren), 'infants' => 0, 'extraBeds' => 0, 'label' => '1 adult + 2 children'];
                        if ($maxAdults > 2) $rows[] = ['roomTypeId' => $id, 'adults' => $maxAdults, 'children' => 0, 'infants' => 0, 'extraBeds' => 0, 'label' => "{$maxAdults} adults"];
                    }
                    Rows::insertMany('occupancy_rules', $rows);
                }
                if (array_key_exists('bedding', $b)) {
                    DB::table('room_bedding')->where('room_type_id', $id)->delete();
                    $allowed = ['extra_bed', 'sofa_bed', 'baby_cot'];
                    $rows = [];
                    foreach ($b['bedding'] as $item) {
                        $item = is_array($item) ? $item : [];
                        $kind = self::s($item['kind'] ?? null);
                        $max = max(0, min(4, (int) self::n($item['maxPerRoom'] ?? null)));
                        if (! in_array($kind, $allowed, true) || $max === 0) continue;
                        $rows[] = ['roomTypeId' => $id, 'kind' => $kind, 'label' => self::or($item['label'] ?? null, ucfirst(str_replace('_', ' ', $kind))), 'maxPerRoom' => $max, 'free' => self::truthy($item['free'] ?? null), 'ratePerNight' => max(0, self::n($item['ratePerNight'] ?? null)), 'perStay' => self::truthy($item['perStay'] ?? null), 'sortOrder' => (array_search($kind, $allowed, true) + 1) * 10];
                    }
                    Rows::insertMany('room_bedding', $rows);
                }
            });
            return self::json(['room' => Rows::find('room_types', $id)]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => Rows::isUnique($e) ? 'That room code already exists for this hotel.' : 'Unable to update this room type.'], 400);
        }
    }

    public function roomsDelete(Request $r)
    {
        [, $err] = Auth::guard('rooms');
        if ($err) return $err;
        $id = (int) self::n($r->query('id'));
        if ($id < 1) return self::json(['error' => 'Room type id is required.'], 400);
        try {
            $result = DB::transaction(function () use ($id) {
                if (! DB::table('room_types')->where('id', $id)->exists()) return ['missing' => true];
                $refs = ['bookings' => DB::table('bookings')->where('room_type_id', $id)->count(), 'bookingItems' => DB::table('booking_items')->where('room_type_id', $id)->count(), 'quotationItems' => DB::table('quotation_items')->where('room_type_id', $id)->count()];
                if (array_sum($refs)) return ['references' => $refs];
                DB::table('room_types')->where('id', $id)->delete();
                return ['deleted' => true];
            });
            if (! empty($result['missing'])) return self::json(['error' => 'Room type not found.'], 404);
            if (isset($result['references'])) return self::json(['error' => 'This room type is linked to saved bookings or quotations. It cannot be deleted; set its inventory to 0 or deactivate it to preserve history.', 'references' => $result['references']], 409);
            return self::json(['ok' => true]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to delete this room type. Existing linked records were preserved.'], 409);
        }
    }

    public function ratesUpdate(Request $r)
    {
        [, $err] = Auth::guard('rates');
        if ($err) return $err;
        try {
            $b = self::body($r);
            $id = (int) self::n($b['id'] ?? null);
            $current = $id > 0 ? Rows::find('rate_periods', $id) : null;
            if (! $current) return self::json(['error' => 'Rate plan not found.'], 404);
            $value = fn (string $key, $fallback) => array_key_exists($key, $b) ? $b[$key] : $fallback;
            $name = trim(self::s($value('name', $current['name'])));
            $from = trim(self::s($value('validFrom', $current['validFrom'])));
            $to = trim(self::s($value('validTo', $current['validTo'])));
            $isDate = fn ($date) => (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', self::s($date));
            if (! $name || ! $isDate($from) || ! $isDate($to) || $to < $from) return self::json(['error' => 'Rate name and a valid stay date range are required.'], 400);
            $rawStart = $value('bookingWindowStart', $current['bookingWindowStart']);
            $rawEnd = $value('bookingWindowEnd', $current['bookingWindowEnd']);
            $windowStart = $isDate($rawStart) ? self::s($rawStart) : null;
            $windowEnd = $isDate($rawEnd) ? self::s($rawEnd) : null;
            if ($windowStart && $windowEnd && $windowEnd < $windowStart) return self::json(['error' => 'The booking window end must be after its start.'], 400);
            $market = trim(self::s($value('market', $current['market']))) ?: 'all';
            if ($market !== 'all' && ! preg_match('/^[a-z0-9_]+$/', $market)) $market = 'all';
            $rawExclusions = $value('marketExclusions', $current['marketExclusions']);
            $rawExclusions = is_array($rawExclusions) ? $rawExclusions : preg_split('/[,;]/', self::s($rawExclusions));
            $exclusions = [];
            foreach ($rawExclusions as $item) {
                $item = strtolower(trim(self::s($item)));
                if ($item !== 'all' && preg_match('/^[a-z0-9_]+$/', $item)) $exclusions[$item] = true;
            }
            $rate = Rows::update('rate_periods', $id, [
                'name' => $name, 'boardType' => self::s($value('boardType', $current['boardType'])), 'validFrom' => $from, 'validTo' => $to,
                'bookingWindowStart' => $windowStart, 'bookingWindowEnd' => $windowEnd, 'market' => $market, 'marketExclusions' => implode(',', array_keys($exclusions)),
                'promoCode' => trim(self::s($value('promoCode', $current['promoCode']))), 'baseRate' => max(0, self::n($value('baseRate', $current['baseRate']))),
                'rateBasis' => self::s($value('rateBasis', $current['rateBasis'])), 'boardAdultSupplement' => max(0, self::n($value('boardAdultSupplement', $current['boardAdultSupplement']))),
                'boardChildSupplement' => max(0, self::n($value('boardChildSupplement', $current['boardChildSupplement']))), 'boardSupplementBasis' => self::s($value('boardSupplementBasis', $current['boardSupplementBasis'])),
                'extraAdultRate' => max(0, self::n($value('extraAdultRate', $current['extraAdultRate']))), 'extraChildRate' => max(0, self::n($value('extraChildRate', $current['extraChildRate']))),
                'extraBedRate' => max(0, self::n($value('extraBedRate', $current['extraBedRate']))), 'extraBedBasis' => self::s($value('extraBedBasis', $current['extraBedBasis'])),
                'minimumNights' => max(1, (int) self::n($value('minimumNights', $current['minimumNights']))), 'active' => array_key_exists('active', $b) ? self::truthy($b['active']) : $current['active'],
            ]);
            return self::json(['rate' => $rate]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to update this rate plan.'], 400);
        }
    }

    /** Create an inactive copy of an existing rate; the admin can review it before enabling. */
    public function ratesDuplicate(Request $r)
    {
        [, $err] = Auth::guard('rates');
        if ($err) return $err;
        try {
            $body = self::body($r);
            $id = (int) self::n($body['id'] ?? null);
            $source = $id > 0 ? Rows::find('rate_periods', $id) : null;
            if (! $source) return self::json(['error' => 'Rate plan not found.'], 404);
            $copy = Rows::insert('rate_periods', [
                'hotelId' => $source['hotelId'], 'roomTypeId' => $source['roomTypeId'],
                'name' => mb_substr($source['name'].' (copy)', 0, 180),
                'boardType' => $source['boardType'], 'validFrom' => $source['validFrom'], 'validTo' => $source['validTo'],
                'bookingWindowStart' => $source['bookingWindowStart'], 'bookingWindowEnd' => $source['bookingWindowEnd'],
                'market' => $source['market'], 'marketExclusions' => $source['marketExclusions'], 'promoCode' => $source['promoCode'],
                'baseRate' => $source['baseRate'], 'rateBasis' => $source['rateBasis'],
                'boardAdultSupplement' => $source['boardAdultSupplement'], 'boardChildSupplement' => $source['boardChildSupplement'],
                'boardSupplementBasis' => $source['boardSupplementBasis'], 'extraAdultRate' => $source['extraAdultRate'],
                'extraChildRate' => $source['extraChildRate'], 'extraBedRate' => $source['extraBedRate'],
                'extraBedBasis' => $source['extraBedBasis'], 'minimumNights' => $source['minimumNights'], 'active' => false,
            ]);
            return self::json(['rate' => $copy], 201);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to duplicate this rate plan.'], 400);
        }
    }

    public function ratesDelete(Request $r)
    {
        [, $err] = Auth::guard('rates');
        if ($err) return $err;
        $id = (int) self::n($r->query('id'));
        if ($id < 1) return self::json(['error' => 'Rate plan id is required.'], 400);
        try {
            $result = DB::transaction(function () use ($id) {
                if (! DB::table('rate_periods')->where('id', $id)->exists()) return ['missing' => true];
                $refs = ['bookings' => DB::table('bookings')->where('rate_period_id', $id)->count(), 'bookingItems' => DB::table('booking_items')->where('rate_period_id', $id)->count(), 'quotationItems' => DB::table('quotation_items')->where('rate_period_id', $id)->count()];
                if (array_sum($refs)) return ['references' => $refs];
                DB::table('rate_periods')->where('id', $id)->delete();
                return ['deleted' => true];
            });
            if (! empty($result['missing'])) return self::json(['error' => 'Rate plan not found.'], 404);
            if (isset($result['references'])) return self::json(['error' => 'This rate is linked to saved bookings or quotations. It cannot be deleted; deactivate it instead to preserve sales history.', 'references' => $result['references']], 409);
            return self::json(['ok' => true]);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['error' => 'Unable to delete this rate. Existing linked records were preserved.'], 409);
        }
    }
}
