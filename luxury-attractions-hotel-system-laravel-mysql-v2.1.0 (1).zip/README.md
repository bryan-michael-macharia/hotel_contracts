# Luxury Attractions Hotel Contracts — Laravel 12 + MySQL · v2.1.0

Fresh-install package for PHP 8.2/8.3 hosting with MySQL/MariaDB. The browser installer creates the
admin account and database tables. This archive includes the full Laravel application, Composer
vendor dependencies, migration, optional demo catalogue, installer and the v2.1.0 hotel-management
overlay. No `.env`, live customer records, user credentials, or `public/check.php` are included.

## Screens and features

- Search & compare negotiated hotel rates
- Quotations, PDF proposals, email, trip packages and bookings
- Hotel, room, inventory, occupancy, bedding, rate/board and blackout management
- **Edit and history-protected delete** for hotels, room types and rate plans
- **Duplicate rate plan** creates an inactive draft so it cannot unexpectedly affect search
- **Manage services, tours & tickets** from Trip Packages (requires `catalog` permission): create
  shared/private transfer services, tours and attraction tickets with their prices
- Users, role permissions, SMTP and installer

Deleting a hotel, room or rate used by a saved booking or quotation is refused, preserving historical
records. Deleting a catalogue item leaves copied details and price on existing trip-package lines.

## Install

See `INSTALL.txt` in this archive. Install into a **new** project folder with a **new** MySQL database.
Do not extract this complete archive over the live site; for the existing Laravel 2.0.0 deployment,
use the smaller CRUD overlay ZIP and back up MySQL first.
