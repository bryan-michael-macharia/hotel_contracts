# Luxury Attractions Hotel Contracts — Laravel 12 + MySQL · v2.1.1

Fresh-install package for PHP 8.2/8.3 hosting with MySQL/MariaDB. The browser installer creates the
admin account and database tables. This archive includes the full Laravel application, Composer vendor
dependencies with autoload maps rebuilt for the included application files (including removing stale classmap paths), MySQL migration, optional
demo catalogue, browser installer and hotel-management enhancements. It contains no `.env`, live customer
records, user credentials or `public/check.php`.

## Screens and features

- Search & compare negotiated hotel rates
- Quotations, PDF proposals, email, trip packages and bookings
- Hotel, room, inventory, occupancy, bedding, rate/board and blackout management
- Edit and history-protected delete for hotels, room types and rate plans
- Duplicate a rate plan as an inactive draft; review it and activate it when ready
- **+ Add Services / Tours / Tickets** button visible across the dashboard to users with the `catalog`
  permission (administrators have access automatically): create shared/private transfers, services,
  tours and attraction tickets with price tiers
- Users, role permissions, SMTP and browser installer

Deleting a hotel, room or rate referenced by booking or quotation history is refused, preserving historical
records. Removing a catalog entry preserves copied details and prices on existing trip-package lines.

## Install

Use `INSTALL.txt`. Extract to a **new** application folder and connect a **new** MySQL database. Do not
extract the complete installer over the existing live site; for that use the small `luxury-attractions-hotel-system-laravel-v2.1.0-update.zip` overlay.
